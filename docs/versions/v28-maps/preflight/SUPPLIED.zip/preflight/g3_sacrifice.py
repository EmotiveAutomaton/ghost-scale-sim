"""G3 SACRIFICE_MOMENTS pre-flight. numpy only, seed fixed, log space."""
import numpy as np, time, itertools
STEPS, NW = 512, 200
CLASSES = [('TOOL', 2), ('TOOL', 4), ('SAVER', 10), ('SAVER', 15), ('SAVER', 20), ('CAPTURED', 3), ('CAPTURED', 5)]
WEIGHTS = [(2, 2), (3, 1), (1, 3)]
HY = [(c, w) for c in range(len(CLASSES)) for w in range(3)]
NH = len(HY)
HC = np.array([h[0] for h in HY]); HW = np.array([h[1] for h in HY])
WA = np.array([WEIGHTS[w][0] for w in HW], float); WB = np.array([WEIGHTS[w][1] for w in HW], float)
TRUTHS = [('CAPTURED(3)', 5), ('CAPTURED(5)', 6), ('SAVER(10)', 2), ('SAVER(20)', 4), ('TOOL(2)', 0)]
SAVERS = [2, 3, 4]; SAVER_R = {2: 10, 3: 15, 4: 20}

def keep(M):  # M: (nw,) -> (nw, NH)
    out = np.zeros((len(M), NH))
    for h, (c, w) in enumerate(HY):
        ty, p = CLASSES[c]
        if ty == 'CAPTURED': out[:, h] = p
        else: out[:, h] = np.where(M <= p, 3.0, 0.0)
    return out

def lse(a, axis):
    m = np.max(a, axis=axis, keepdims=True); m = np.where(np.isfinite(m), m, 0.0)
    with np.errstate(divide='ignore'):
        return np.squeeze(m, axis) + np.log(np.sum(np.exp(a - m), axis=axis))

def run(tclass, q_in, q_need, seed, nw=NW, steps=STEPS, only_deficit=False):
    rng = np.random.default_rng(seed)
    tw = rng.integers(3, size=nw); th = tclass * 3 + tw            # true hypothesis per world
    M = np.full(nw, 5); dA = np.zeros(nw, int); dB = np.zeros(nw, int)
    LL = np.zeros((nw, NH))
    cls_post = np.zeros((steps, nw, 7)); w_post = np.zeros((steps, nw, 3))
    rec = dict(M=np.zeros((steps, nw), int), dA=np.zeros((steps, nw), int), dB=np.zeros((steps, nw), int),
               a=np.zeros((steps, nw), int), nodef_change=0.0)
    for t in range(steps):
        M = np.minimum(30, M + (rng.random(nw) < q_in))
        dA = np.minimum(3, dA + (rng.random(nw) < q_need)); dB = np.minimum(3, dB + (rng.random(nw) < q_need))
        k = keep(M)
        vA = np.where(((M > 0) & (dA > 0))[:, None], WA * dA[:, None] - k, -np.inf)
        vB = np.where(((M > 0) & (dB > 0))[:, None], WB * dB[:, None] - k, -np.inf)
        V = np.stack([np.zeros((nw, NH)), vA, vB], -1)
        lp = V - lse(V, 2)[..., None]
        pa = np.exp(lp[np.arange(nw), th]); a = (rng.random(nw)[:, None] > np.cumsum(pa, 1)).sum(1)
        inc = lp[np.arange(nw), :, a]
        nodef = (dA == 0) & (dB == 0)
        rec['nodef_change'] = max(rec['nodef_change'], np.abs(inc[nodef]).max() if nodef.any() else 0.0)
        if only_deficit: inc = np.where(nodef[:, None], 0.0, inc)
        LL += inc
        cls_post[t] = np.stack([lse(np.where(HC == c, LL, -np.inf), 1) - np.log(3) for c in range(7)], 1)
        w_post[t] = np.stack([lse(np.where(HW == w, LL, -np.inf), 1) - np.log(7) for w in range(3)], 1)
        rec['M'][t], rec['dA'][t], rec['dB'][t], rec['a'][t] = M, dA, dB, a
        M = M - (a > 0); dA = dA - (a == 1); dB = dB - (a == 2)
    rec['tw'] = tw; rec['LL'] = LL
    return cls_post, w_post, rec

def first_sep(lo):  # lo: (steps,nw) log-odds; returns records-to-separate, inf if censored
    ok = lo >= 1; notok = ~ok; S = lo.shape[0]
    last_bad = np.where(notok.any(0), S - 1 - np.argmax(notok[::-1], 0), -1)
    return np.where(ok[-1], last_bad + 2, np.inf)

def med(x):
    return 'alias' if np.mean(~np.isfinite(x)) > 0.5 else '%d' % np.median(x)

if __name__ == '__main__':
    t0 = time.process_time()
    # ---- checks ----
    tc = time.process_time()
    cp, wp, rc = run(5, 0.5, 0.15, 1)
    print('CPU s one cell (200 worlds x 512 steps): %.2f' % (time.process_time() - tc))
    print('CHECK max |log-lik increment| on no-deficit steps (must be 0):', rc['nodef_change'])
    # CAPTURED(3) vs SAVER(R) identical whenever M<=R: rerun step-wise check on recorded states
    M = rc['M'].ravel(); kk = keep(M)
    for R, c in [(10, 2), (15, 3), (20, 4)]:
        same = np.all(kk[:, HC == 5] == kk[:, HC == c], 1)
        print('CHECK keep(CAPTURED3)==keep(SAVER%d) on steps with M<=%d: %s; share of steps with M<=%d: %.3f' % (R, R, bool(same[M <= R].all()), R, (M <= R).mean()))
    for name, c in TRUTHS:
        cp, wp, rc = run(c, 0.5, 0.3, 11, nw=100, steps=2000)
        fin = cp[-1]; P = np.exp(fin - lse(fin, 1)[:, None])
        Pw = np.exp(wp[-1] - lse(wp[-1], 1)[:, None])
        print('CHECK long run (2000 steps, q_in .5, q_need .3) truth %-11s: mean p(true class) %.3f, mean p(true weights) %.3f'
              % (name, P[:, c].mean(), Pw[np.arange(100), rc['tw']].mean()))
    # ---- grid ----
    G = {}
    for gi, (qi, qn) in enumerate(itertools.product([0.3, 0.5, 0.8], [0.05, 0.15, 0.3])):
        for ti, (name, c) in enumerate(TRUTHS):
            G[(qi, qn, name)] = run(c, qi, qn, 100 + 10 * gi + ti)
    print('grid CPU s: %.1f' % (time.process_time() - t0))
    print('\n(a) truth CAPTURED(3) vs SAVER(10) | SAVER(15) | SAVER(20): median records (censored share)')
    print('q_in\\q_need  ' + ''.join('%-44s' % qn for qn in [0.05, 0.15, 0.3]))
    for qi in [0.3, 0.5, 0.8]:
        row = []
        for qn in [0.05, 0.15, 0.3]:
            cp = G[(qi, qn, 'CAPTURED(3)')][0]
            row.append(' '.join('%s(%.2f)' % (med(r), np.mean(~np.isfinite(r))) for r in [first_sep(cp[:, :, 5] - cp[:, :, s]) for s in SAVERS]))
        print('%-12s' % qi + ''.join('%-44s' % r for r in row))
    print('\n(a2) all pairs, truth (row) vs rival class (col), median records (censored share), centre q_in .5 q_need .15')
    names = ['%s(%d)' % c for c in CLASSES]
    print('%-12s' % '' + ''.join('%-13s' % n for n in names))
    for name, c in TRUTHS:
        cp = G[(0.5, 0.15, name)][0]
        print('%-12s' % name + ''.join('%-13s' % ('-' if b == c else '%s(%.2f)' % (med(first_sep(cp[:, :, c] - cp[:, :, b])), np.mean(~np.isfinite(first_sep(cp[:, :, c] - cp[:, :, b]))))) for b in range(7)))
    print('\n(a3) every setting: censored share for each truth vs its hardest rival (rival named)')
    for qi in [0.3, 0.5, 0.8]:
        for qn in [0.05, 0.15, 0.3]:
            parts = []
            for name, c in TRUTHS:
                cp = G[(qi, qn, name)][0]
                cs = [(np.mean(~np.isfinite(first_sep(cp[:, :, c] - cp[:, :, b]))), names[b]) for b in range(7) if b != c]
                cs.sort(reverse=True); parts.append('%s: %.2f vs %s' % (name, cs[0][0], cs[0][1]))
            print('q_in %.1f q_need %.2f  ' % (qi, qn) + ' | '.join(parts))
    print('\n(b) share of worlds where M ever exceeds 10 / 20, and share of steps with M>20 and some deficit>=1')
    for qi in [0.3, 0.5, 0.8]:
        for qn in [0.05, 0.15, 0.3]:
            parts = []
            for name, c in TRUTHS:
                r = G[(qi, qn, name)][2]; Mx = r['M']; df = (r['dA'] > 0) | (r['dB'] > 0)
                parts.append('%s %.2f/%.2f/%.3f' % (name, (Mx > 10).any(0).mean(), (Mx > 20).any(0).mean(), ((Mx > 20) & df).mean()))
            print('q_in %.1f q_need %.2f  ' % (qi, qn) + ' | '.join(parts))
    print('\n(c-i) sacrifice moments before CAPTURED(3) separates from SAVER(20) [spec def: M > largest SAVER R with p(SAVER(R))>=0.01, some deficit>=1];'
          ' alt: M>20 and some deficit. median over separated worlds')
    for qi in [0.3, 0.5, 0.8]:
        row = []
        for qn in [0.05, 0.15, 0.3]:
            cp, wp, r = G[(qi, qn, 'CAPTURED(3)')]
            P = cp - lse(cp, 2)[..., None]
            prior = np.concatenate([np.full((1, cp.shape[1], 7), -np.log(7)), P[:-1]], 0)   # posterior before step t
            Rmax = np.full(prior.shape[:2], -1)
            for s in SAVERS:
                Rmax = np.where(prior[:, :, s] >= np.log(0.01), SAVER_R[s], Rmax)
            df = (r['dA'] > 0) | (r['dB'] > 0)
            sm = (r['M'] > Rmax) & df & (Rmax >= 0)
            sm_alt = (r['M'] > 20) & df
            sep = first_sep(cp[:, :, 5] - cp[:, :, 4])
            ok = np.isfinite(sep)
            if ok.sum() == 0: row.append('none sep'); continue
            idx = np.arange(STEPS)[:, None]
            n1 = ((idx < sep[None]) & sm).sum(0)[ok]; n2 = ((idx < sep[None]) & sm_alt).sum(0)[ok]
            row.append('%d / %d (n=%d)' % (np.median(n1), np.median(n2), ok.sum()))
        print('q_in %.1f   ' % qi + ''.join('%-24s' % x for x in row))
    print('\n(c-ii) deficit-only reader: share of final class log-odds (CAPTURED3 vs SAVER20, truth CAPTURED3) kept, centre and two corners')
    for qi, qn in [(0.5, 0.15), (0.8, 0.05), (0.3, 0.3)]:
        full = run(5, qi, qn, 999)[0]; part = run(5, qi, qn, 999, only_deficit=True)[0]
        fl = full[-1, :, 5] - full[-1, :, 4]; pl = part[-1, :, 5] - part[-1, :, 4]
        print('  q_in %.1f q_need %.2f: median share kept %.4f, max |diff| %.2e' % (qi, qn, np.median(pl / np.where(fl == 0, 1, fl)), np.abs(fl - pl).max()))
    print('\n(c-iii) weights (3,1) vs (1,3): records to separate (truth weights (3,1) worlds, all truth types pooled) and share of the final log-odds earned on both-deficit steps')
    for qi in [0.3, 0.5, 0.8]:
        row = []
        for qn in [0.05, 0.15, 0.3]:
            recs, shares, shares_any = [], [], []
            for name, c in TRUTHS:
                cp, wp, r = G[(qi, qn, name)]
                sel = r['tw'] == 1
                lo = wp[:, sel, 1] - wp[:, sel, 2]
                recs.append(first_sep(lo))
                inc = np.diff(np.concatenate([np.zeros((1, sel.sum())), lo], 0), axis=0)
                both = (r['dA'][:, sel] > 0) & (r['dB'][:, sel] > 0)
                tot = lo[-1]
                shares.append((inc * both).sum(0) / np.where(tot == 0, np.nan, tot))
            rr = np.concatenate(recs); sh = np.concatenate(shares)
            row.append('%s(%.2f) both-share %.2f' % (med(rr), np.mean(~np.isfinite(rr)), np.nanmedian(sh)))
        print('q_in %.1f   ' % qi + ''.join('%-32s' % x for x in row))
    print('\n(extra) share of steps with both deficits present; share with some deficit; mean M, by setting (truth CAPTURED(3))')
    for qi in [0.3, 0.5, 0.8]:
        print('q_in %.1f  ' % qi + '  '.join('qn %.2f: both %.2f any %.2f meanM %.1f' % (qn, ((G[(qi, qn, 'CAPTURED(3)')][2]['dA'] > 0) & (G[(qi, qn, 'CAPTURED(3)')][2]['dB'] > 0)).mean(),
              ((G[(qi, qn, 'CAPTURED(3)')][2]['dA'] > 0) | (G[(qi, qn, 'CAPTURED(3)')][2]['dB'] > 0)).mean(), G[(qi, qn, 'CAPTURED(3)')][2]['M'].mean()) for qn in [0.05, 0.15, 0.3]))
    print('\n(extra) final mean p(true class) by truth and setting')
    for qi in [0.3, 0.5, 0.8]:
        for qn in [0.05, 0.15, 0.3]:
            parts = []
            for name, c in TRUTHS:
                fin = G[(qi, qn, name)][0][-1]; parts.append('%s %.2f' % (name, np.exp(fin[:, c] - lse(fin, 1)).mean()))
            print('q_in %.1f q_need %.2f  ' % (qi, qn) + ' | '.join(parts))
    print('\ntotal CPU s: %.1f' % (time.process_time() - t0))
