"""G1 extension (analyst check): empirical-habit EM loop (PeL), disjoint high overlap. numpy only."""
import numpy as np, time, itertools, sys
V, H, G = 12, 8, 4
def lse(a, axis):
    m = np.max(a, axis=axis, keepdims=True)
    return np.squeeze(m, axis) + np.log(np.sum(np.exp(a - m), axis=axis))
def norm(a):
    return a - lse(a, -1)[..., None]
def library(rng, ov):
    h = rng.dirichlet(np.full(V, 0.3), size=H)
    if ov == 'low':
        perm = rng.permutation(V); trip = perm[:12].reshape(4, 3)
    else:  # high2: goal g takes habit g's top moves not already taken (disjoint triples)
        taken = set(); trip = np.zeros((G, 3), int)
        for g in range(G):
            order = [v for v in np.argsort(-h[g]) if v not in taken][:3]
            trip[g] = order; taken.update(order)
    t = np.full((G, V), 0.1 / V)
    for g in range(G): t[g, trip[g]] += 0.9 / 3
    return h, t
def run_cell(K, rho, ov, T, seed, BLOCKS=80, PER=50):
    rng = np.random.default_rng(seed)
    names = ['J', 'Ps', 'Pe', 'PeL1', 'PeL4', 'PeL16', 'I1']
    out = {r: [] for r in names}
    for b in range(BLOCKS):
        h, t = library(rng, ov)
        m = (1 - rho) * h[:, None, :] + rho * t[None, :, :]
        lm, lh = np.log(m), np.log(h)
        W = PER
        i_true = rng.integers(H, size=W); g_true = rng.integers(G, size=W)
        def gen(gs):
            z = rng.random((W, T)) < rho
            xs = np.empty((W, T), int)
            for w in range(W):
                n1 = z[w].sum()
                xs[w, z[w]] = rng.choice(V, size=n1, p=t[gs[w]])
                xs[w, ~z[w]] = rng.choice(V, size=T - n1, p=h[i_true[w]])
            return xs
        x = gen(g_true)
        c = np.stack([np.bincount(r, minlength=V) for r in x]).astype(float)
        Ch = np.zeros((W, max(K, 1), V))
        for k in range(K):
            xh = gen(rng.integers(G, size=W))
            Ch[:, k] = np.stack([np.bincount(r, minlength=V) for r in xh])
        csum = Ch[:, :K].sum(1) if K else np.zeros((W, V))
        logL = np.einsum('wv,hgv->whg', c, lm)
        if K:
            lhd = np.einsum('wkv,hgv->wkhg', Ch[:, :K], lm)
            lph = (lse(lhd, 3) - np.log(G)).sum(1)
        else:
            lph = np.zeros((W, H))
        lph = norm(lph)
        pJ = norm(lse(lph[:, :, None] + logL, 1))
        lq = norm((c + csum) @ lh.T)
        pS = norm(lse(lq[:, :, None] + logL, 1))
        hh = (c + csum + 0.5); hh = hh / hh.sum(1, keepdims=True)
        def goal_post(hhat, counts):  # counts W,V -> log p(g) W,G
            me = (1 - rho) * hhat[:, None, :] + rho * t[None]
            return norm(np.einsum('wv,wgv->wg', counts, np.log(me)))
        pE = goal_post(hh, c)
        # EM loop on the empirical habit: all docs (target + K history docs)
        docs = [c] + [Ch[:, k] for k in range(K)]
        def em(n):
            hhat = hh.copy()
            for _ in range(n):
                acc = np.full((W, V), 0.5)
                for d in docs:
                    pg = np.exp(goal_post(hhat, d))                      # W,G
                    me = (1 - rho) * hhat[:, None, :] + rho * t[None]     # W,G,V
                    keep = (1 - rho) * hhat[:, None, :] / me              # prob token is habit, W,G,V
                    acc += d * np.einsum('wg,wgv->wv', pg, keep)
                hhat = acc / acc.sum(1, keepdims=True)
            return goal_post(hhat, c)
        p = pS.copy()
        lqq = norm(lph + lse(p[:, None, :] + logL, 2)); pI1 = norm(lse(lqq[:, :, None] + logL, 1))
        res = dict(J=pJ, Ps=pS, Pe=pE, PeL1=em(1), PeL4=em(4), PeL16=em(16), I1=pI1)
        for r, pp in res.items(): out[r].append(pp[np.arange(W), g_true])
    return {r: np.concatenate(v) for r, v in out.items()}
if __name__ == '__main__':
    t0 = time.process_time()
    print('cell: J mean | gap to J (nats) Ps Pe PeL1 PeL4 PeL16 I1 | tail share p<.01: J Ps Pe PeL4 | paired SE of J-PeL4')
    for ci, (ov, rho, K) in enumerate(itertools.product(['low', 'high2'], [0.2, 0.3, 0.4], [0, 1, 4, 16])):
        R = run_cell(K, rho, ov, 64, 5000 + ci)
        J = R['J']
        gaps = ' '.join('%5.2f' % (J.mean() - R[r].mean()) for r in ['Ps', 'Pe', 'PeL1', 'PeL4', 'PeL16', 'I1'])
        tails = ' '.join('%.3f' % (np.mean(R[r] < np.log(0.01))) for r in ['J', 'Ps', 'Pe', 'PeL4'])
        se = (J - R['PeL4']).std() / np.sqrt(len(J))
        print('%-5s rho %.1f K %2d: %6.3f | %s | %s | %.3f' % (ov, rho, K, J.mean(), gaps, tails, se))
        sys.stdout.flush()
    print('CPU s', round(time.process_time() - t0, 1))
