"""G1 JOINT_WITH_HISTORY pre-flight. numpy only, seed fixed, log space."""
import numpy as np, time, itertools
V, H, G = 12, 8, 4
BLOCKS, PER = 8, 50
KS, RHOS, OVS, TS = [0, 1, 4, 16], [0.1, 0.2, 0.4], ['low', 'high'], [32, 64, 128]
READERS = ['J', 'Ps', 'Pt', 'Pe', 'I1', 'I4', 'B1', 'B2', 'B4', 'B8']

def lse(a, axis):
    m = np.max(a, axis=axis, keepdims=True)
    return np.squeeze(m, axis) + np.log(np.sum(np.exp(a - m), axis=axis))

def norm(a, axis=-1):
    return a - lse(a, axis)[..., None] if axis == -1 else a - np.expand_dims(lse(a, axis), axis)

def rankavg(x):
    o = np.argsort(x, kind='mergesort'); xs = x[o]
    r = np.empty(len(x)); i = 0
    # average ranks over ties
    _, start, cnt = np.unique(xs, return_index=True, return_counts=True)
    avg = start + (cnt - 1) / 2.0 + 1
    r[o] = np.repeat(avg, cnt)
    return r

def auc(score, lab):
    lab = lab.astype(bool); n1 = lab.sum(); n0 = len(lab) - n1
    if n1 == 0 or n0 == 0: return np.nan
    r = rankavg(score)
    return (r[lab].sum() - n1 * (n1 + 1) / 2) / (n1 * n0)

def library(rng, ov):
    h = rng.dirichlet(np.full(V, 0.3), size=H)
    if ov == 'low':
        perm = rng.permutation(V); trip = perm[:12].reshape(4, 3)
    else:
        trip = np.argsort(-h[:G], axis=1)[:, :3]
    t = np.full((G, V), 0.1 / V)
    for g in range(G): t[g, trip[g]] += 0.9 / 3
    return h, t, trip

def run_cell(K, rho, ov, T, seed, PER=PER):
    rng = np.random.default_rng(seed)
    out = {r: [] for r in READERS}; acc = {r: [] for r in READERS}; mx = {r: [] for r in READERS}
    tokJ, tokE, tokZ, tokO = [], [], [], []
    overlap_frac = []
    for b in range(BLOCKS):
        h, t, trip = library(rng, ov)
        m = (1 - rho) * h[:, None, :] + rho * t[None, :, :]       # H,G,V
        lm, lh, lt = np.log(m), np.log(h), np.log(t)
        W = PER
        i_true = rng.integers(H, size=W); g_true = rng.integers(G, size=W)
        def gen(gs):  # tokens for W docs with goals gs
            z = rng.random((W, T)) < rho
            xs = np.empty((W, T), int)
            for w in range(W):
                n1 = z[w].sum()
                xs[w, z[w]] = rng.choice(V, size=n1, p=t[gs[w]])
                xs[w, ~z[w]] = rng.choice(V, size=T - n1, p=h[i_true[w]])
            return xs, z
        x, z = gen(g_true)
        c = np.stack([np.bincount(r, minlength=V) for r in x]).astype(float)  # W,V
        Ch = np.zeros((W, max(K, 1), V))
        for k in range(K):
            xh, _ = gen(rng.integers(G, size=W))
            Ch[:, k] = np.stack([np.bincount(r, minlength=V) for r in xh])
        csum = Ch[:, :K].sum(1) if K else np.zeros((W, V))
        # J
        logL = np.einsum('wv,hgv->whg', c, lm)                    # W,H,G
        if K:
            lhd = np.einsum('wkv,hgv->wkhg', Ch[:, :K], lm)
            lph = (lse(lhd, 3) - np.log(G)).sum(1)                 # W,H
        else:
            lph = np.zeros((W, H))
        lph = norm(lph)
        pJ = norm(lse(lph[:, :, None] + logL, 1))
        # Ps
        lq = norm((c + csum) @ lh.T)                               # W,H
        pS = norm(lse(lq[:, :, None] + logL, 1))
        # Pt
        ih = lq.argmax(1)
        pT = norm(logL[np.arange(W), ih])
        # Pe
        hh = (c + csum + 0.5) / (c + csum + 0.5).sum(1, keepdims=True)  # W,V
        me = (1 - rho) * hh[:, None, :] + rho * t[None]           # W,G,V
        pE = norm(np.einsum('wv,wgv->wg', c, np.log(me)))
        # I(n)
        def loop(n):
            p = pS.copy()
            for _ in range(n):
                lqq = norm(lph + lse(p[:, None, :] + logL, 2))
                p = norm(lse(lqq[:, :, None] + logL, 1))
            return p
        pI1, pI4 = loop(1), loop(4)
        # B(k)
        sc = lph + c @ lh.T
        order = np.argsort(-sc, axis=1)
        def beam(k):
            mask = np.full((W, H), -np.inf)
            np.put_along_axis(mask, order[:, :k], 0.0, axis=1)
            return norm(lse((lph + mask)[:, :, None] + logL, 1))
        res = dict(J=pJ, Ps=pS, Pt=pT, Pe=pE, I1=pI1, I4=pI4, B1=beam(1), B2=beam(2), B4=beam(4), B8=beam(8))
        for r, p in res.items():
            out[r].append(p[np.arange(W), g_true]); acc[r].append(p.argmax(1) == g_true)
            mx[r].append(np.exp(p.max(1)))
        # departure marks
        post = norm((lph[:, :, None] + logL).reshape(W, -1)).reshape(W, H, G)
        pz_v = np.einsum('whg,hgv->wv', np.exp(post), rho * t[None] / m)   # W,V
        ge = pE.argmax(1)
        pze_v = rho * t[ge] / me[np.arange(W), ge]                         # W,V
        tokJ.append(np.take_along_axis(pz_v, x, 1).ravel()); tokE.append(np.take_along_axis(pze_v, x, 1).ravel())
        tokZ.append(z.ravel())
        pzo = rho * t[g_true] / m[i_true, g_true]   # oracle: true i and g known
        tokO.append(np.take_along_axis(pzo, x, 1).ravel())
        overlap_frac.append(np.mean([len(set(trip[a]) & set(trip[bb])) > 0 for a in range(G) for bb in range(a + 1, G)]))
    R = {}
    for r in READERS:
        ls = np.concatenate(out[r]); a = np.concatenate(acc[r]); mm = np.concatenate(mx[r])
        R[r] = dict(ls=ls.mean(), se=ls.std() / np.sqrt(len(ls)), acc=a.mean(), cal=mm.mean() - a.mean(), raw=ls)
    zz = np.concatenate(tokZ)
    R['aucJ'] = auc(np.concatenate(tokJ), zz); R['aucE'] = auc(np.concatenate(tokE), zz); R['aucO'] = auc(np.concatenate(tokO), zz)
    R['ovl'] = np.mean(overlap_frac)
    return R

if __name__ == '__main__':
    t0 = time.process_time()
    # ---- known-answer checks ----
    Rc = run_cell(4, 0.2, 'low', 64, 999)
    assert np.allclose(Rc['B8']['raw'], Rc['J']['raw']), 'B(H) != J'
    print('CHECK B(8)==J max abs diff:', np.abs(Rc['B8']['raw'] - Rc['J']['raw']).max())
    print('CHECK J calibration (should be ~0): %.4f; J log-score %.3f >= Ps %.3f, Pe %.3f' %
          (Rc['J']['cal'], Rc['J']['ls'], Rc['Ps']['ls'], Rc['Pe']['ls']))
    Rr = run_cell(0, 1e-9 + 0.999999, 'low', 64, 7)  # rho ~ 1: no habit tokens, all readers ~ equal
    print('CHECK rho~1: J %.4f Ps %.4f Pe %.4f (should match)' % (Rr['J']['ls'], Rr['Ps']['ls'], Rr['Pe']['ls']))
    tc = time.process_time()
    Rc2 = run_cell(16, 0.2, 'high', 128, 1); print('CPU s for heaviest cell (K16,T128):', round(time.process_time() - tc, 2))
    # ---- grid ----
    ALL = {}
    for (ci, (K, rho, ov, T)) in enumerate(itertools.product(KS, RHOS, OVS, TS)):
        ALL[(K, rho, ov, T)] = run_cell(K, rho, ov, T, 1000 + ci)
    print('grid CPU s total:', round(time.process_time() - t0, 1))
    f = lambda v: '%+.3f' % v
    for ov in OVS:
        print('\n(a) T=64 overlap=%s  [J-Ps | J-Pe | J-Pt] nats (J mean log-score, J acc)' % ov)
        print('K   ' + '  '.join(['rho=%-27s' % r for r in RHOS]))
        for K in KS:
            row = []
            for rho in RHOS:
                R = ALL[(K, rho, ov, 64)]
                row.append('%s %s %s (%.2f,%.2f)' % (f(R['J']['ls'] - R['Ps']['ls']), f(R['J']['ls'] - R['Pe']['ls']),
                                                    f(R['J']['ls'] - R['Pt']['ls']), R['J']['ls'], R['J']['acc']))
            print('%-3d ' % K + ' | '.join(row))
    print('\nmean pairwise-triple overlap share (high overlap):', round(np.mean([ALL[k]['ovl'] for k in ALL if k[2] == 'high']), 3))
    print('\n(b) gap J(K)-P(K) in nats for K=0,1,4,16; ratio to K=0 gap; Kmin = smallest K with gap <= 10% of K=0 gap (only if K=0 gap >= 0.02)')
    for ov in OVS:
        for T in TS:
            for rho in RHOS:
                s_ = []
                for P in ['Ps', 'Pe']:
                    gaps = [ALL[(K, rho, ov, T)]['J']['ls'] - ALL[(K, rho, ov, T)][P]['ls'] for K in KS]
                    if gaps[0] < 0.02:
                        s_.append('%s gaps=%s  Kmin=n/a(no K=0 gap)' % (P, ' '.join('%.3f' % g for g in gaps))); continue
                    kk = [K for K, g in zip(KS, gaps) if g <= 0.1 * gaps[0]]
                    s_.append('%s gaps=%s  Kmin=%s' % (P, ' '.join('%.3f' % g for g in gaps), kk[0] if kk else '>16'))
                print('%-4s T=%-3d rho=%.1f  ' % (ov, T, rho) + ' || '.join(s_))
    print('\n(b2) tail: share of worlds with p(true goal)<0.01, J / Ps / Pt / Pe, T=64')
    for ov in OVS:
        for rho in RHOS:
            print('%-4s rho=%.1f ' % (ov, rho) + '  '.join('K=%d %s' % (K, '/'.join('%.3f' % (ALL[(K, rho, ov, 64)][r]['raw'] < np.log(0.01)).mean() for r in ['J', 'Ps', 'Pt', 'Pe'])) for K in KS))
    print('\n(b3) paired SE of J-Ps (nats), T=64')
    for ov in OVS:
        print('%-4s ' % ov + ' | '.join(' '.join('%.3f' % ((ALL[(K, rho, ov, 64)]['J']['raw'] - ALL[(K, rho, ov, 64)]['Ps']['raw']).std() / 20) for K in KS) for rho in RHOS))
    print('\n(c) K=0: gain share (R-Ps)/(J-Ps) and calibration (mean maxp - acc); T=64')
    for ov in OVS:
        for rho in RHOS:
            R = ALL[(0, rho, ov, 64)]; d = R['J']['ls'] - R['Ps']['ls']
            print('%-4s rho=%.1f J-Ps=%.3f  ' % (ov, rho, d) + '  '.join(
                '%s:%s/cal%+.3f' % (r, ('%+.2f' % ((R[r]['ls'] - R['Ps']['ls']) / d)) if d >= 0.02 else ('d%+.3f' % (R[r]['ls'] - R['Ps']['ls'])), R[r]['cal']) for r in ['I1', 'I4', 'B1', 'B2', 'B4', 'Ps', 'J']))
    print('\n(c2) same at T=32 and T=128, rho=0.2')
    for ov in OVS:
        for T in [32, 128]:
            R = ALL[(0, 0.2, ov, T)]; d = R['J']['ls'] - R['Ps']['ls']
            print('%-4s T=%d J-Ps=%.3f  ' % (ov, T, d) + '  '.join(
                '%s:%+.2f/cal%+.3f' % (r, (R[r]['ls'] - R['Ps']['ls']) / d, R[r]['cal']) for r in ['I1', 'I4', 'B1', 'B2', 'B4', 'Ps', 'J']))
    print('\n(d) sign checks over all 72 cells: share of cells with mean J >= R; min (J-R)/se')
    for r in READERS[1:]:
        dif = np.array([ALL[k]['J']['ls'] - ALL[k][r]['ls'] for k in ALL])
        z = np.array([(ALL[k]['J']['raw'] - ALL[k][r]['raw']).mean() / ((ALL[k]['J']['raw'] - ALL[k][r]['raw']).std() / 20 + 1e-12) for k in ALL])
        print('%-3s J>=R in %d/72 cells, min diff %+.4f, min z %+.2f' % (r, (dif >= -1e-12).sum(), dif.min(), z.min()))
    print('Ps vs Pt identical cells:', sum(np.allclose(ALL[k]['Ps']['raw'], ALL[k]['Pt']['raw']) for k in ALL))
    print('\n(e) departure-mark AUC  J / Pe / oracle(true i,g)  (T=64)')
    for ov in OVS:
        for rho in RHOS:
            print('%-4s rho=%.1f ' % (ov, rho) + '  '.join('K=%d %.3f/%.3f/%.3f' % (K, ALL[(K, rho, ov, 64)]['aucJ'], ALL[(K, rho, ov, 64)]['aucE'], ALL[(K, rho, ov, 64)]['aucO']) for K in KS))
    print('\n(f) cells with J-Ps >= 0.05 nats (value; z of paired diff)')
    for ov in OVS:
        for T in TS:
            line = []
            for rho in RHOS:
                for K in KS:
                    R = ALL[(K, rho, ov, T)]; d = R['J']['raw'] - R['Ps']['raw']
                    line.append('%s' % ('#' if d.mean() >= 0.05 else '.'))
                line.append(' ')
            print('%-4s T=%-3d ' % (ov, T) + ''.join(line) + '   (blocks rho=.1/.2/.4, each K=0,1,4,16)')
    print('\nfull J-Ps table (nats) by T,rho,K:')
    for ov in OVS:
        for T in TS:
            print('%-4s T=%-3d ' % (ov, T) + ' | '.join(' '.join('%.3f' % (ALL[(K, rho, ov, T)]['J']['ls'] - ALL[(K, rho, ov, T)]['Ps']['ls']) for K in KS) for rho in RHOS))
    print('\nfull J-Pe table (nats) by T,rho,K:')
    for ov in OVS:
        for T in TS:
            print('%-4s T=%-3d ' % (ov, T) + ' | '.join(' '.join('%.3f' % (ALL[(K, rho, ov, T)]['J']['ls'] - ALL[(K, rho, ov, T)]['Pe']['ls']) for K in KS) for rho in RHOS))
    print('\nJ accuracy by T,rho,K:')
    for ov in OVS:
        for T in TS:
            print('%-4s T=%-3d ' % (ov, T) + ' | '.join(' '.join('%.2f' % ALL[(K, rho, ov, T)]['J']['acc'] for K in KS) for rho in RHOS))
    print('\n(robust) J-Ps and J-Pe at 400 vs 4000 worlds, T=64, rho=0.2 and 0.4 (paired SE)')
    for ov in OVS:
        for rho in [0.2, 0.4]:
            for K in KS:
                R = run_cell(K, rho, ov, 64, 77000 + K, PER=500)
                d = R['J']['raw'] - R['Ps']['raw']; e = R['J']['raw'] - R['Pe']['raw']
                print('%-4s rho=%.1f K=%-2d  400: J-Ps %.3f J-Pe %.3f | 4000: J-Ps %.3f+-%.3f J-Pe %.3f+-%.3f  Ps tail<0.01 %.3f' % (ov, rho, K,
                      ALL[(K, rho, ov, 64)]['J']['ls'] - ALL[(K, rho, ov, 64)]['Ps']['ls'], ALL[(K, rho, ov, 64)]['J']['ls'] - ALL[(K, rho, ov, 64)]['Pe']['ls'],
                      d.mean(), d.std() / np.sqrt(len(d)), e.mean(), e.std() / np.sqrt(len(e)), (R['Ps']['raw'] < np.log(0.01)).mean()))
    print('total CPU s:', round(time.process_time() - t0, 1))
