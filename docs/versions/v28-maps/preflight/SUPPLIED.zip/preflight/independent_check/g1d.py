import g1, numpy as np
from scipy.special import logsumexp
orig=g1.em_goal
def em_hard(C,H0,G,rho,rounds):
    H=H0
    for r in range(rounds+1):
        lm=np.log(rho*G[None]+(1-rho)*H[:,None,:]); ll=np.einsum('wdx,wgx->wdg',C,lm)
        if r==rounds: return ll[:,0,:]-logsumexp(ll[:,0,:],axis=1,keepdims=True)
        q=np.zeros_like(ll); np.put_along_axis(q,ll.argmax(2)[...,None],1.0,2)
        hresp=((1-rho)*H[:,None,:])/(rho*G[None]+(1-rho)*H[:,None,:])
        # hard token attribution: token attributed to goal if goal prob share >0.5
        R=np.einsum('wdg,wgx->wdx',q,(hresp<0.5).astype(float)*0+ (hresp>=0.5))
        hc=(C*R).sum(1)+0.5; H=hc/hc.sum(1,keepdims=True)
for name,f in [('soft(pre-flight reading)',orig),('hard MAP goal and hard token attribution',em_hard)]:
    g1.em_goal=f
    for ov in ['low','high']:
        r=g1.run_cell(0.3,ov,0,8000,seed=5)
        print(name,ov,'Pe-PeL4 logscore diff',round((r['Pe']-r['PeL4']).mean(),3))
