import g1, numpy as np
for ov in ['low','high']:
    r=g1.run_cell(0.3,ov,0,40000,seed=77)
    for k in ['Ps','Pe','PeL4','I1']:
        d=r['J']-r[k]; print(ov,k,round(d.mean(),3),round(d.std()/np.sqrt(len(d)),3))
    print(ov,'registered stat: Pe minus PeL4 logscore', round((r['Pe']-r['PeL4']).mean(),3))
r=g1.run_cell(0.4,'low',16,4000,seed=3); d=r['J']-r['PeL4']; print('K16 rho.4 low PeL4 gap',round(d.mean(),4))
