import g1, numpy as np
for ov in ['low','high']:
    r=g1.run_cell(0.3,ov,0,8000,seed=5)
    for k in ['Pe','PeL4']:
        d=r['J']-r[k]; b=d.reshape(-1,50).mean(1)
        print(ov,k,'gap',round(d.mean(),3),'SE worlds',round(d.std()/np.sqrt(len(d)),4),'SE blocks',round(b.std(ddof=1)/np.sqrt(len(b)),4))
    d=r['Pe']-r['PeL4']; b=d.reshape(-1,50).mean(1)
    print(ov,'Pe-PeL4 ',round(d.mean(),3),'SE worlds',round(d.std()/np.sqrt(len(d)),4),'SE blocks',round(b.std(ddof=1)/np.sqrt(len(b)),4))
# rho near 1 check
for rho in [0.9,0.97]:
    r=g1.run_cell(rho,'low',0,2000,seed=9)
    print('rho',rho,{k:round((r['J']-r[k]).mean(),4) for k in ['Ps','I1','Pe','PeL4']})
