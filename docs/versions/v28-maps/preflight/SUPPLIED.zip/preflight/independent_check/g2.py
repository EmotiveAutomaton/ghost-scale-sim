import numpy as np
from scipy.special import logsumexp
SMAX, COST = 24, 3
DP = np.array([0.5, 0.35, 0.15])

def logp_table(theta_lo, theta_hi, pi, spend):
    # returns (25, 3) log action probs; action 0 hold,1 restore,2 spend (-inf if no spend)
    s = np.arange(SMAX + 1)
    v = np.full((SMAX + 1, 3), -np.inf)
    v[:, 0] = 0
    v[:, 1] = pi * np.maximum(0, theta_lo - s) - COST
    if spend:
        v[:, 2] = pi * np.maximum(0, s - theta_hi) - COST
    return v - logsumexp(v, axis=1, keepdims=True)

def simulate(lp, nworld, T, rng, s0=12):
    s = np.full(nworld, s0)
    S = np.zeros((nworld, T), int); A = np.zeros((nworld, T), int)
    P = np.exp(lp)
    for t in range(T):
        S[:, t] = s
        u = rng.random(nworld)
        c = np.cumsum(P[s], axis=1)
        a = (u[:, None] > c).sum(1); a = np.minimum(a, 2)
        A[:, t] = a
        s = np.clip(s + COST * (a == 1) - COST * (a == 2), 0, SMAX)
        d = rng.choice(3, nworld, p=DP)
        s = np.clip(s - d, 0, SMAX)
    return S, A

def loglik(lp, S, A):
    return lp[S, A].sum(1)

rng = np.random.default_rng(5)
# G2a
thetas = [8, 10, 12, 14, 16, 18, 20]; pis = [0.5, 1, 2]
lp_true = logp_table(12, 12, 1, False)
S, A = simulate(lp_true, 200, 256, rng)
print('ONE never spends:', (A == 2).sum())
print('share steps s<theta-2:', (S < 10).mean())
LL = np.array([[loglik(logp_table(th, th, p, False), S, A) for p in pis] for th in thetas])  # (7,3,W)
post = np.exp(LL - logsumexp(LL.reshape(-1, 200), axis=0))
pth = post.sum(1)
print('posterior theta=12 at 256: mean', pth[2].mean(), 'median', np.median(pth[2]), 'share>=0.9', (pth[2] >= 0.9).mean())

# Table 4
tgrid = list(range(4, 23)); pgrid = [0.25, 0.5, 1, 2, 4]
for name, spend in [('POINT', True), ('ONE', False)]:
    lp = logp_table(12, 12, 1, spend)
    S, A = simulate(lp, 100, 256, np.random.default_rng(11 if spend else 12))
    LL = np.array([[loglik(logp_table(th, th, p, True), S, A) for p in pgrid] for th in tgrid])  # (19,5,W)
    flat = LL.reshape(-1, 100)
    best = flat.argmax(0)
    ft = np.array(tgrid)[best // 5]; fp = np.array(pgrid)[best % 5]
    vals, cnt = np.unique(fp, return_counts=True)
    print(name, 'median theta', np.median(ft), 'modal pi', vals[cnt.argmax()], dict(zip(vals, cnt)),
          'share (12,1):', ((ft == 12) & (fp == 1)).mean())
    vt, ct = np.unique(ft, return_counts=True); print('   theta counts', dict(zip(vt, ct)))
