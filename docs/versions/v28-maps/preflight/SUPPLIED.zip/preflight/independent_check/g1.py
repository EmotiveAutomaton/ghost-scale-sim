import numpy as np, sys
from scipy.special import logsumexp

NM, NT, NG, NTOK = 12, 8, 4, 64

def make_goals(H, overlap, rng):
    if overlap == 'low':
        perm = rng.permutation(NM)
        trip = [perm[3*g:3*g+3] for g in range(NG)]
    else:
        taken = set(); trip = []
        for g in range(NG):
            order = np.argsort(-H[g], kind='stable')
            pick = [m for m in order if m not in taken][:3]
            taken |= set(pick); trip.append(np.array(pick))
    G = np.full((NG, NM), 0.1 / NM)
    for g in range(NG):
        G[g, trip[g]] += 0.3
    return G

def em_goal(C, H0, G, rho, rounds):
    # C: (W,D,12) counts, page is doc 0. H0: (W,12). returns log goal posterior of page (W,4)
    H = H0
    for r in range(rounds + 1):
        mix = rho * G[None, None] + (1 - rho) * H[:, None, None, :]   # (W,1,4,12)
        ll = np.einsum('wdx,wdgx->wdg', C, np.log(mix[:, 0:1].repeat(1, 1)))  if False else None
        lm = np.log(rho * G[None] + (1 - rho) * H[:, None, :])        # (W,4,12)
        ll = np.einsum('wdx,wgx->wdg', C, lm)                          # (W,D,4)
        q = np.exp(ll - logsumexp(ll, axis=2, keepdims=True))          # (W,D,4)
        if r == rounds:
            return ll[:, 0, :] - logsumexp(ll[:, 0, :], axis=1, keepdims=True)
        # habit responsibility per token under goal g
        hresp = ((1 - rho) * H[:, None, :]) / (rho * G[None] + (1 - rho) * H[:, None, :])  # (W,4,12)
        R = np.einsum('wdg,wgx->wdx', q, hresp)                        # (W,D,12)
        hc = (C * R).sum(1) + 0.5
        H = hc / hc.sum(1, keepdims=True)

def run_cell(rho, overlap, K, nworld, seed, goals_per_world=False):
    rng = np.random.default_rng(seed)
    out = {k: [] for k in ['J', 'Ps', 'I1', 'Pe', 'PeL4']}
    acc = {k: [] for k in out}
    nb = nworld // 50
    for b in range(nb):
        Lib = rng.dirichlet(np.full(NM, 0.3), NT)
        G = make_goals(Lib, overlap, rng)
        W = 50
        t = rng.integers(0, NT, W)
        gt = rng.integers(0, NG, (W, K + 1))   # doc 0 is the page
        if goals_per_world:
            pass
        P = rho * G[gt] + (1 - rho) * Lib[t][:, None, :]    # (W,D,12)
        C = np.zeros((W, K + 1, NM))
        for w in range(W):
            for d in range(K + 1):
                C[w, d] = rng.multinomial(NTOK, P[w, d])
        lm = np.log(rho * G[None, :, None, :] + (1 - rho) * Lib[:, None, None, :])  # (T,G,1,12)->use below
        lm = np.log(rho * G[None, :, :] + (1 - rho) * Lib[:, None, :])               # (T,G,12)
        ll = np.einsum('wdx,tgx->wdtg', C, lm)                                       # (W,D,T,G)
        page = ll[:, 0]                                                              # (W,T,G)
        if K > 0:
            hist = logsumexp(ll[:, 1:], axis=3) - np.log(NG)                         # (W,K,T)
            hist = hist.sum(1)                                                       # (W,T)
        else:
            hist = np.zeros((W, NT))
        # J
        lj = logsumexp(page + hist[:, :, None], axis=1)                              # (W,G)
        lj -= logsumexp(lj, axis=1, keepdims=True)
        # Ps: type from all tokens as habit
        Call = C.sum(1)
        lt = Call @ np.log(Lib).T                                                    # (W,T)
        pt = np.exp(lt - logsumexp(lt, axis=1, keepdims=True))
        lps = logsumexp(page + np.log(pt)[:, :, None], axis=1)
        lps -= logsumexp(lps, axis=1, keepdims=True)
        # I(1)
        q = np.exp(lps)                                                              # (W,G)
        lt2 = hist + logsumexp(page + np.log(q + 1e-300)[:, None, :], axis=2)        # (W,T)
        lt2 -= logsumexp(lt2, axis=1, keepdims=True)
        li1 = logsumexp(page + lt2[:, :, None], axis=1)
        li1 -= logsumexp(li1, axis=1, keepdims=True)
        # Pe
        Hh = Call + 0.5; Hh = Hh / Hh.sum(1, keepdims=True)
        lpe = em_goal(C, Hh, G, rho, 0)
        lpl = em_goal(C, Hh, G, rho, 4)
        for k, l in [('J', lj), ('Ps', lps), ('I1', li1), ('Pe', lpe), ('PeL4', lpl)]:
            out[k].append(l[np.arange(W), gt[:, 0]])
    res = {k: np.concatenate(v) for k, v in out.items()}
    return res

if __name__ == '__main__':
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 4000
    for ov in ['low', 'high']:
        for K in [0, 4]:
            r = run_cell(0.3, ov, K, n, seed=1000 + K + (7 if ov == 'high' else 0))
            s = f'{ov:5s} K={K}: J={r["J"].mean():.3f} '
            for k in ['I1', 'Ps', 'Pe', 'PeL4']:
                d = r['J'] - r[k]
                s += f'{k} gap={d.mean():.3f}+-{d.std()/np.sqrt(len(d)):.3f}  '
            print(s, flush=True)
