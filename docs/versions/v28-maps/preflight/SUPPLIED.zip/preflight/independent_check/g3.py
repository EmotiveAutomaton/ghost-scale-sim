import numpy as np
from scipy.special import logsumexp
MMAX, DMAX = 30, 3
WTS = [(2, 2), (3, 1), (1, 3)]

def keep_fn(kind, par, M):
    M = np.asarray(M)
    if kind == 'CAP':
        return np.full(M.shape, float(par))
    return np.where(M <= par, 3.0, 0.0)  # TOOL(r) and SAVER(R)

def logprob(kind, par, w, M, dA, dB):
    # returns (n,3) log probs over [hold, A, B]
    k = keep_fn(kind, par, M)
    v = np.full(M.shape + (3,), -np.inf)
    v[..., 0] = 0
    okA = (M > 0) & (dA > 0); okB = (M > 0) & (dB > 0)
    v[..., 1] = np.where(okA, w[0] * dA - k, -np.inf)
    v[..., 2] = np.where(okB, w[1] * dB - k, -np.inf)
    return v - logsumexp(v, axis=-1, keepdims=True)

def simulate(kind, par, w, q_in, q_need, nworld, T, rng, M0=5):
    M = np.full(nworld, M0) if M0 is not None else rng.integers(0, 31, nworld)
    dA = np.zeros(nworld, int); dB = np.zeros(nworld, int)
    Ms = np.zeros((nworld, T), int); As = Ms.copy(); Bs = Ms.copy(); Act = Ms.copy()
    for t in range(T):
        M = np.minimum(MMAX, M + (rng.random(nworld) < q_in))
        dA = np.minimum(DMAX, dA + (rng.random(nworld) < q_need))
        dB = np.minimum(DMAX, dB + (rng.random(nworld) < q_need))
        Ms[:, t], As[:, t], Bs[:, t] = M, dA, dB
        lp = logprob(kind, par, w if np.ndim(w) == 1 else None, M, dA, dB) if np.ndim(w) == 1 else None
        P = np.exp(lp); c = np.cumsum(P, axis=1)
        a = np.minimum((rng.random(nworld)[:, None] > c).sum(1), 2)
        Act[:, t] = a
        M = M - (a > 0); dA = dA - (a == 1); dB = dB - (a == 2)
    return Ms, As, Bs, Act

def run(q_in, q_need, nw=200, T=512, M0=5, seed=3):
    rng = np.random.default_rng(seed)
    # truth CAPTURED(3), weights uniform from 3 pairs: simulate per weight group
    res = {}
    seps = []; never = 0; moments = []; zero_ok = True
    for i in range(nw):
        w = WTS[rng.integers(3)]
        Ms, As, Bs, Act = simulate('CAP', 3, np.array(w), q_in, q_need, 1, T, rng, M0)
        M, dA, dB, a = Ms[0], As[0], Bs[0], Act[0]
        def cum(kind, par):
            out = []
            for ww in WTS:
                lp = logprob(kind, par, ww, M, dA, dB)
                l = lp[np.arange(T), a]
                if i == 0 or True:
                    nn = (dA == 0) & (dB == 0)
                    if np.any(np.abs(l[nn]) > 0): nonlocal_flag[0] = False
                out.append(np.concatenate([[0], np.cumsum(l)]))
            return logsumexp(np.array(out), axis=0)
        lo = cum('CAP', 3) - cum('SAV', 10)
        bad = np.where(lo < 1)[0]
        last = bad.max()
        if last >= T: never += 1
        else: seps.append(last + 1)
    allv=np.array(seps+[np.inf]*never)
    print('  median incl never as inf:',np.median(allv))
    return np.median(seps) if seps else np.inf, never / nw, len(seps)

nonlocal_flag = [True]
if __name__ == '__main__':
    for qi, qn in [(0.5, 0.15), (0.3, 0.15), (0.5, 0.3)]:
        med, nv, ns = run(qi, qn)
        print(f'q_in={qi} q_need={qn}: median records to separate CAP3 vs SAV10 (among separated) = {med}, never = {nv:.3f}, n_sep={ns}')
    print('no-unmet-need steps change no likelihood:', nonlocal_flag[0])
