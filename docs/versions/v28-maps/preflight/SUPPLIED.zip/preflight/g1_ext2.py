"""G1 extension 2 (analyst check): population-prior readers. Pp = one 'typical maker' habit (library mean).
PpS(a) = Dirichlet prior centred on the population habit with strength a, updated by the maker's tokens (one pass).
PpSL(a) = the same with the EM loop (4 rounds) that removes tokens attributed to goals."""
import numpy as np, itertools, sys, time
from g1_ext import lse, norm, library, V, H, G
def run_cell(K, rho, ov, T, seed, BLOCKS=80, PER=50, A=(8.0, 32.0)):
    rng = np.random.default_rng(seed)
    names = ['J', 'Pe', 'Pp'] + ['PpS%d' % a for a in A] + ['PpSL%d' % a for a in A]
    out = {r: [] for r in names}
    for b in range(BLOCKS):
        h, t = library(rng, ov)
        m = (1 - rho) * h[:, None, :] + rho * t[None, :, :]; lm = np.log(m)
        W = PER; i_true = rng.integers(H, size=W); g_true = rng.integers(G, size=W)
        def gen(gs):
            z = rng.random((W, T)) < rho; xs = np.empty((W, T), int)
            for w in range(W):
                n1 = z[w].sum()
                xs[w, z[w]] = rng.choice(V, size=n1, p=t[gs[w]]); xs[w, ~z[w]] = rng.choice(V, size=T - n1, p=h[i_true[w]])
            return xs
        x = gen(g_true); c = np.stack([np.bincount(r, minlength=V) for r in x]).astype(float)
        Ch = np.zeros((W, max(K, 1), V))
        for k in range(K):
            Ch[:, k] = np.stack([np.bincount(r, minlength=V) for r in gen(rng.integers(G, size=W))])
        csum = Ch[:, :K].sum(1) if K else np.zeros((W, V))
        logL = np.einsum('wv,hgv->whg', c, lm)
        lph = norm((lse(np.einsum('wkv,hgv->wkhg', Ch[:, :K], lm), 3) - np.log(G)).sum(1)) if K else norm(np.zeros((W, H)))
        res = {'J': norm(lse(lph[:, :, None] + logL, 1))}
        def goal_post(hhat, counts):
            me = (1 - rho) * hhat[:, None, :] + rho * t[None]
            return norm(np.einsum('wv,wgv->wg', counts, np.log(me)))
        hh = (c + csum + 0.5); hh /= hh.sum(1, keepdims=True); res['Pe'] = goal_post(hh, c)
        hbar = np.tile(h.mean(0), (W, 1)); res['Pp'] = goal_post(hbar, c)
        docs = [c] + [Ch[:, k] for k in range(K)]
        for a in A:
            prior = a * hbar
            h1 = prior + c + csum; h1 /= h1.sum(1, keepdims=True); res['PpS%d' % a] = goal_post(h1, c)
            hhat = h1.copy()
            for _ in range(4):
                acc = prior.copy()
                for d in docs:
                    pg = np.exp(goal_post(hhat, d)); me = (1 - rho) * hhat[:, None, :] + rho * t[None]
                    acc += d * np.einsum('wg,wgv->wv', pg, (1 - rho) * hhat[:, None, :] / me)
                hhat = acc / acc.sum(1, keepdims=True)
            res['PpSL%d' % a] = goal_post(hhat, c)
        for r, pp in res.items(): out[r].append(pp[np.arange(W), g_true])
    return {r: np.concatenate(v) for r, v in out.items()}, names
if __name__ == '__main__':
    t0 = time.process_time()
    for ci, (ov, rho, K) in enumerate(itertools.product(['low', 'high2'], [0.2, 0.4], [0, 1, 4, 16])):
        R, names = run_cell(K, rho, ov, 64, 7000 + ci)
        if ci == 0: print('gap to J in nats:', ' '.join(names[1:]), '| tail p<.01 for the same')
        J = R['J']
        print('%-5s rho %.1f K %2d | %s | %s' % (ov, rho, K, ' '.join('%5.2f' % (J.mean() - R[r].mean()) for r in names[1:]),
              ' '.join('%.3f' % np.mean(R[r] < np.log(0.01)) for r in names[1:]))); sys.stdout.flush()
    print('CPU s', round(time.process_time() - t0, 1))
