"""G2 signature table pre-flight (analyst): fit POINT by maximum likelihood to records from each truth. Cost 3, regime N, 256 steps."""
import numpy as np, sys
C = 3.0; S0 = 12; STEPS = 256
def probs(s, lo, hi, pi, spend_ok):
    v = np.array([0.0, pi * max(0.0, lo - s) - C, (pi * max(0.0, s - hi) - C) if spend_ok else -np.inf])
    v = v - v.max(); p = np.exp(v); return p / p.sum()
def simulate(kind, rng, theta=12, pi=1.0, w=4, lam=0.1, kap=0.1):
    s = S0; lo = float(theta); n = m = 0; S = np.empty(STEPS, int); A = np.empty(STEPS, int); LL = 0.0
    for t in range(STEPS):
        if kind == 'MOVE' and t > 0: lo = min(20.0, max(2.0, lo + lam * (S[t - 1] - lo)))
        n = n + 1 if s < theta - 2 else 0; m = m + 1 if abs(s - theta) <= 2 else 0
        pit = pi * np.exp(-kap * n) if kind == 'DULL' else (pi * min(3.0, 1 + kap * m) if kind == 'SHARP' else pi)
        hi = lo if kind == 'POINT' else (lo + w if kind == 'BAND' else 99)
        p = probs(s, lo, hi, pit, kind in ('POINT', 'BAND'))
        a = rng.choice(3, p=p); S[t] = s; A[t] = a; LL += np.log(p[a])
        s = s + (3 if a == 1 else (-3 if a == 2 else 0)); s = s - rng.choice(3, p=[0.5, 0.35, 0.15]); s = min(24, max(0, s))
    return S, A, LL
THETAS = np.arange(4, 23); PIS = np.array([0.25, 0.5, 1, 2, 4])
def fit_point(S, A):
    best = (-np.inf, None, None)
    for th in THETAS:
        for pi in PIS:
            vr = pi * np.maximum(0, th - S) - C; vs = pi * np.maximum(0, S - th) - C
            V = np.stack([np.zeros(len(S)), vr, vs], 1); V = V - V.max(1, keepdims=True)
            lp = V - np.log(np.exp(V).sum(1, keepdims=True)); ll = lp[np.arange(len(S)), A].sum()
            if ll > best[0]: best = (ll, th, pi)
    return best
rng = np.random.default_rng(20261111)
print('truth | fitted theta: median (10th, 90th) | share exact theta 12 | within 1 | fitted pi mode (share) | loss nats/step vs truth | mean stock | spend share')
for kind in ['POINT', 'ONE', 'BAND', 'MOVE', 'DULL', 'SHARP']:
    th, pi, loss, ms, sp = [], [], [], [], []
    for wld in range(200):
        S, A, LL = simulate(kind, rng); ll, t_, p_ = fit_point(S, A)
        th.append(t_); pi.append(p_); loss.append((LL - ll) / STEPS); ms.append(S.mean()); sp.append((A == 2).mean())
    th = np.array(th); pi = np.array(pi); vals, cnt = np.unique(pi, return_counts=True)
    print('%-5s | %4.1f (%d, %d) | %.2f | %.2f | %s (%.2f) | %.3f | %.1f | %.3f' % (kind, np.median(th), np.percentile(th, 10), np.percentile(th, 90), np.mean(th == 12), np.mean(np.abs(th - 12) <= 1),
          vals[cnt.argmax()], cnt.max() / len(pi), np.mean(loss), np.mean(ms), np.mean(sp))); sys.stdout.flush()
