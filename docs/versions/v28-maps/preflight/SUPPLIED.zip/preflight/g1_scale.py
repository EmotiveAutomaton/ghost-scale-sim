"""G1 scale-up cell (analyst pre-flight): V=200 moves, H=32 habit types, G=8 goals with 10 target moves, T=256."""
import numpy as np, itertools, sys, time
V, H, G, NT, T = 200, 32, 8, 10, 256
def lse(a, axis):
    m = np.max(a, axis=axis, keepdims=True); return np.squeeze(m, axis) + np.log(np.sum(np.exp(a - m), axis=axis))
def norm(a): return a - lse(a, -1)[..., None]
def library(rng, ov):
    h = rng.dirichlet(np.full(V, 0.3), size=H) + 1e-12; h /= h.sum(1, keepdims=True)
    if ov == 'low':
        trip = rng.permutation(V)[:G * NT].reshape(G, NT)
    else:
        taken = set(); trip = np.zeros((G, NT), int)
        for g in range(G):
            order = [v for v in np.argsort(-h[g]) if v not in taken][:NT]; trip[g] = order; taken.update(order)
    t = np.full((G, V), 0.1 / V)
    for g in range(G): t[g, trip[g]] += 0.9 / NT
    return h, t
def run_cell(K, rho, ov, seed, BLOCKS=16, PER=50):
    rng = np.random.default_rng(seed); names = ['J', 'Ps', 'I1', 'Pp', 'Pe', 'PeL4']; out = {r: [] for r in names}; aucs = {r: [] for r in ['J', 'Pe', 'PeL4', 'Pp']}
    for b in range(BLOCKS):
        h, t = library(rng, ov); m = (1 - rho) * h[:, None, :] + rho * t[None]; lm, lh = np.log(m), np.log(h)
        W = PER; i_true = rng.integers(H, size=W); g_true = rng.integers(G, size=W)
        def gen(gs):
            z = rng.random((W, T)) < rho; xs = np.empty((W, T), int)
            for w in range(W):
                n1 = z[w].sum(); xs[w, z[w]] = rng.choice(V, size=n1, p=t[gs[w]]); xs[w, ~z[w]] = rng.choice(V, size=T - n1, p=h[i_true[w]])
            return xs, z
        x, z = gen(g_true); c = np.stack([np.bincount(r, minlength=V) for r in x]).astype(float)
        Ch = np.zeros((W, max(K, 1), V))
        for k in range(K): Ch[:, k] = np.stack([np.bincount(r, minlength=V) for r in gen(rng.integers(G, size=W))[0]])
        csum = Ch[:, :K].sum(1) if K else np.zeros((W, V))
        logL = np.einsum('wv,hgv->whg', c, lm)
        lph = norm((lse(np.einsum('wkv,hgv->wkhg', Ch[:, :K], lm), 3) - np.log(G)).sum(1)) if K else norm(np.zeros((W, H)))
        pJ = norm(lse(lph[:, :, None] + logL, 1))
        lq = norm((c + csum) @ lh.T); pS = norm(lse(lq[:, :, None] + logL, 1))
        lqq = norm(lph + lse(pS[:, None, :] + logL, 2)); pI1 = norm(lse(lqq[:, :, None] + logL, 1))
        def goal_post(hhat, counts):
            me = (1 - rho) * hhat[:, None, :] + rho * t[None]; return norm(np.einsum('wv,wgv->wg', counts, np.log(me)))
        hbar = np.tile(h.mean(0), (W, 1)); pP = goal_post(hbar, c)
        hh = (c + csum + 0.5); hh /= hh.sum(1, keepdims=True); pE = goal_post(hh, c)
        docs = [c] + [Ch[:, k] for k in range(K)]; hhat = hh.copy()
        for _ in range(4):
            acc = np.full((W, V), 0.5)
            for d in docs:
                pg = np.exp(goal_post(hhat, d)); me = (1 - rho) * hhat[:, None, :] + rho * t[None]
                acc += d * np.einsum('wg,wgv->wv', pg, (1 - rho) * hhat[:, None, :] / me)
            hhat = acc / acc.sum(1, keepdims=True)
        pL = goal_post(hhat, c)
        for r, pp in dict(J=pJ, Ps=pS, I1=pI1, Pp=pP, Pe=pE, PeL4=pL).items(): out[r].append(pp[np.arange(W), g_true])
        # departure marks: p(z=1 | token) under each reader's habit estimate and its top goal (J: exact marginal)
        post = norm((lph[:, :, None] + logL).reshape(W, -1)).reshape(W, H, G)
        pzJ = np.einsum('whg,hgv->wv', np.exp(post), rho * t[None] / m)
        def marks(hhat, p):
            ge = p.argmax(1); me = (1 - rho) * hhat + rho * t[ge]; return rho * t[ge] / me
        sc = dict(J=pzJ, Pe=marks(hh, pE), PeL4=marks(hhat, pL), Pp=marks(hbar, pP))
        for r, pv in sc.items():
            s = np.take_along_axis(pv, x, 1).ravel(); lab = z.ravel()
            o = np.argsort(s, kind='mergesort'); rk = np.empty(len(s)); rk[o] = np.arange(1, len(s) + 1)
            n1 = lab.sum(); n0 = len(lab) - n1; aucs[r].append((rk[lab].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))
    return {r: np.concatenate(v) for r, v in out.items()}, {r: float(np.mean(v)) for r, v in aucs.items()}
if __name__ == '__main__':
    t0 = time.process_time()
    print('gap to J (nats): Ps I1 Pp Pe PeL4 | tail p<.01: Ps Pp Pe PeL4 | mark AUC (ties broken arbitrarily): J Pe PeL4 Pp')
    for ci, (ov, rho, K) in enumerate(itertools.product(['low', 'high2'], [0.2, 0.4], [0, 1, 4, 16])):
        R, A = run_cell(K, rho, ov, 9000 + ci); J = R['J']
        print('%-5s rho %.1f K %2d | J %.3f | %s | %s | %s' % (ov, rho, K, J.mean(), ' '.join('%5.2f' % (J.mean() - R[r].mean()) for r in ['Ps', 'I1', 'Pp', 'Pe', 'PeL4']),
              ' '.join('%.3f' % np.mean(R[r] < np.log(0.01)) for r in ['Ps', 'Pp', 'Pe', 'PeL4']), ' '.join('%.2f' % A[r] for r in ['J', 'Pe', 'PeL4', 'Pp']))); sys.stdout.flush()
    print('CPU s', round(time.process_time() - t0, 1))
