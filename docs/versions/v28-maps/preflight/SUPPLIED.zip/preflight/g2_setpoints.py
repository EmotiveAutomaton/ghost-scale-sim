"""G2 SETPOINTS_VISIBLE pre-flight. numpy only, seed fixed, log space."""
import numpy as np, time, sys
TYPES = ['ONE', 'POINT', 'BAND', 'MOVE', 'DULL', 'SHARP']
THETAS, PIS = [8, 10, 12, 14], [0.5, 1, 2]
STEPS, NW = 256, 200
DIST = np.array([0.5, 0.35, 0.15])

def build_hyps():
    H = []
    for ty in TYPES:
        for th in THETAS:
            for pi in PIS:
                if ty in ('ONE', 'POINT'): H.append((ty, th, pi, 0.0))
                elif ty == 'BAND': H += [(ty, th, pi, w) for w in (4, 8)]
                elif ty == 'MOVE': H += [(ty, th, pi, l) for l in (0.02, 0.1)]
                else: H += [(ty, th, pi, k) for k in (0.02, 0.1)]
    return H
HY = build_hyps(); NH = len(HY)
TY = np.array([TYPES.index(h[0]) for h in HY]); TH = np.array([h[1] for h in HY], float)
PI = np.array([h[2] for h in HY], float); EX = np.array([h[3] for h in HY], float)
HASSPEND = np.isin(TY, [1, 2]); HI = np.where(TY == 1, TH, np.where(TY == 2, TH + EX, np.inf))

def safe_lse(a, axis):
    m = np.max(a, axis=axis, keepdims=True); m = np.where(np.isfinite(m), m, 0.0)
    with np.errstate(divide='ignore'):
        return np.squeeze(m, axis) + np.log(np.sum(np.exp(a - m), axis=axis))

def hyp_index(ty, th, pi, ex):
    return [k for k, h in enumerate(HY) if h == (ty, th, pi, ex)][0]

def run(truth, regime, seed, cost=1.0, beta=1.0, nw=NW):
    rng = np.random.default_rng(seed)
    s = np.full(nw, 12)
    lo = np.tile(TH, (nw, 1)); n = np.zeros((nw, NH)); mm = np.zeros((nw, NH))
    LL = np.zeros((nw, NH)); s_prev = s.copy()
    post = np.zeros((STEPS, nw, 6)); stock = np.zeros((STEPS, nw), int); acts = np.zeros((STEPS, nw), int)
    pidev = np.zeros((STEPS, nw), bool)
    tcol = truth
    for t in range(STEPS):
        if t > 0:
            mv = TY == 3
            lo[:, mv] = np.clip(lo[:, mv] + EX[mv] * (s_prev[:, None] - lo[:, mv]), 2, 20)
        sc = s[:, None].astype(float)
        defic = sc < TH - 2; n = np.where(defic, n + 1, 0)
        near = np.abs(sc - TH) <= 2; mm = np.where(near, mm + 1, 0)
        pit = np.tile(PI, (nw, 1))
        pit = np.where(TY == 4, PI * np.exp(-EX * n), pit)
        pit = np.where(TY == 5, PI * np.minimum(3, 1 + EX * mm), pit)
        v_hold = np.zeros((nw, NH))
        v_res = pit * np.maximum(0, lo - sc) - cost
        v_sp = np.where(HASSPEND, pit * np.maximum(0, sc - np.where(np.isfinite(HI), HI, 0)) - cost, -np.inf)
        V = beta * np.stack([v_hold, v_res, v_sp], -1)
        lp = V - safe_lse(V, 2)[..., None]                    # nw,NH,3
        pidev[t] = pit[:, tcol] != PI[tcol]
        pa = np.exp(lp[:, tcol]); a = (rng.random(nw)[:, None] > np.cumsum(pa, 1)).sum(1)
        acts[t] = a; stock[t] = s
        LL += lp[np.arange(nw), :, a]
        lt = np.stack([safe_lse(np.where(TY == k, LL, -np.inf), 1) - np.log((TY == k).sum()) for k in range(6)], 1)
        post[t] = lt
        s_prev = s.copy()
        eff = np.where(a == 1, 3, np.where(a == 2, -3, 0))
        if regime == 'D' and 64 <= t <= 127: eff = np.where(a == 1, 0, eff)
        d = rng.choice(3, size=nw, p=DIST)
        s = s + eff - d + (2 if (regime == 'W' and 64 <= t <= 127) else 0)
        s = np.clip(s, 0, 24)
    return post, stock, acts, pidev, LL

def records(post, A):
    """first record count after which ln p(A)/p(B) >= 1 to the end; inf if censored. returns (6,nw)"""
    out = np.full((6, post.shape[1]), np.inf)
    for B in range(6):
        if B == A: continue
        with np.errstate(invalid='ignore'):
            ok = (post[:, :, A] - post[:, :, B]) >= 1                 # steps,nw
        # last step where not ok
        notok = ~ok
        last_bad = np.where(notok.any(0), STEPS - 1 - np.argmax(notok[::-1], 0), -1)
        rec = last_bad + 2                                          # records needed (1-indexed)
        out[B] = np.where(ok[-1], rec, np.inf)
    return out

def classify(R, names, label):
    print('\n(b) [%s] pair resolution by regime (resolved = at most half censored). Format truth>rival' % label)
    cats = {}
    for name in names:
        A = TYPES.index(name.split('.')[0])
        for B in range(6):
            if B == A: continue
            r = tuple(np.mean(~np.isfinite(R[(name, reg)][0][B])) <= 0.5 for reg in 'NDW')
            key = {(True, True, True): 'all regimes', (False, True, False): 'only D', (False, False, True): 'only W',
                   (False, False, False): 'nothing', (False, True, True): 'D and W not N'}.get(r, 'other %s' % (r,))
            cats.setdefault(key, []).append('%s>%s' % (name, TYPES[B]))
    for k, v in cats.items():
        print('  %-14s %s' % (k + ':', ', '.join(v)))

def med(x):
    if np.mean(~np.isfinite(x)) > 0.5: return 'alias'
    return '%d' % np.median(x)

def table(truths, regimes, cost=1.0, beta=1.0, label='', nw=NW, verbose=True):
    res = {}
    for reg in regimes:
        if verbose: print('\n[%s] regime %s: median records to separate truth (row) from rival (col); (censored share)' % (label, reg))
        if verbose: print('%-12s' % 'truth' + ''.join('%-14s' % b for b in TYPES) + 'p(true type)@256  s<th-2  meanS  maxS')
        for ti, (name, A, hidx) in enumerate(truths):
            post, stock, acts, pidev, LL = run(hidx, reg, 5000 + 97 * ti + {'N': 0, 'D': 1, 'W': 2}[reg], cost, beta, nw)
            rec = records(post, A); res[(name, reg)] = (rec, post, stock, acts, pidev)
            fin = post[-1]; pt = np.exp(fin[:, A] - safe_lse(fin, 1))
            row = ''.join('%-14s' % ('-' if B == A else '%s(%.2f)' % (med(rec[B]), np.mean(~np.isfinite(rec[B])))) for B in range(6))
            th = HY[hidx][1]
            if verbose: print('%-12s' % name + row + '%.3f            %.3f   %.1f   %d' % (pt.mean(), (stock < th - 2).mean(), stock.mean(), stock.max()))
    return res

if __name__ == '__main__':
    t0 = time.process_time()
    C = dict(ONE=('ONE', 12, 1, 0.0), POINT=('POINT', 12, 1, 0.0), BAND=('BAND', 12, 1, 4), MOVE=('MOVE', 12, 1, 0.1),
             DULL=('DULL', 12, 1, 0.1), SHARP=('SHARP', 12, 1, 0.1))
    truths = [(k, TYPES.index(v[0]), hyp_index(*v)) for k, v in C.items()]
    truths2 = [('MOVE.02', 3, hyp_index('MOVE', 12, 1, 0.02)), ('DULL.02', 4, hyp_index('DULL', 12, 1, 0.02)),
               ('SHARP.02', 5, hyp_index('SHARP', 12, 1, 0.02))]
    print('hypotheses:', NH, {t: int((TY == k).sum()) for k, t in enumerate(TYPES)})
    # ---- checks ----
    tc = time.process_time()
    post, stock, acts, pidev, LL = run(hyp_index('ONE', 12, 1, 0.0), 'N', 1, nw=50)
    print('CPU s, one cell (50 worlds x 256 steps):', round(time.process_time() - tc, 2))
    best = np.argmax(LL, 1)
    print('CHECK truth ONE(12,pi1): share of worlds whose MAP hypothesis is ONE-type: %.2f; MAP==truth exactly: %.2f; truth LL rank median: %d of %d'
          % (np.mean(TY[best] == 0), np.mean(best == hyp_index('ONE', 12, 1, 0.0)),
             np.median((LL > LL[:, [hyp_index('ONE', 12, 1, 0.0)]]).sum(1)), NH))
    # long run check of identifiability of params: 2000 steps not available (fixed 256) -> use D regime where deficits occur
    post, stock, acts, pidev, LL = run(hyp_index('ONE', 12, 1, 0.0), 'D', 2, nw=50)
    best = np.argmax(LL, 1)
    print('CHECK (regime D) truth ONE(12,1): MAP type ONE share %.2f, MAP theta=12 share %.2f, MAP pi=1 share %.2f'
          % (np.mean(TY[best] == 0), np.mean(TH[best] == 12), np.mean(PI[best] == 1)))
    sp = acts == 2
    print('CHECK: worlds with any spend under ONE truth (must be 0):', int(sp.any(0).sum()))
    # ---- main ----
    print('\n===== CENTRE (cost 1, beta 1) =====')
    R = table(truths + truths2, ['N', 'D', 'W'], label='centre')
    classify(R, [t[0] for t in truths + truths2], 'centre')
    # (c) diagnostics under N
    print('\n(c) under N: share of steps with s<theta-2; share of steps where DULL/SHARP pi_t differs from pi; first spend step for POINT/BAND')
    for name in ['ONE', 'POINT', 'BAND', 'MOVE', 'DULL', 'SHARP', 'DULL.02', 'SHARP.02']:
        rec, post, stock, acts, pidev = R[(name, 'N')]
        fs = np.where((acts == 2).any(0), np.argmax(acts == 2, 0), np.inf)
        print('%-9s s<10: %.3f  pi_t!=pi: %.3f  restore share %.2f  spend share %.2f  median first spend %s  stock quartiles %s' % (
            name, (stock < 10).mean(), pidev.mean(), (acts == 1).mean(), (acts == 2).mean(),
            np.median(fs) if np.isfinite(np.median(fs)) else 'never', np.percentile(stock[64:], [25, 50, 75]).astype(int)))
    for name in ['DULL', 'SHARP', 'DULL.02', 'SHARP.02']:
        for reg in 'NDW':
            rec, post, *_ = R[(name, reg)]
            print('  %s %s: final ln p(own type)/p(ONE) median %.2f, IQR %s' % (name, reg, np.median(post[-1][:, TYPES.index(name.split('.')[0])] - post[-1][:, 0]),
                  np.round(np.percentile(post[-1][:, TYPES.index(name.split('.')[0])] - post[-1][:, 0], [25, 75]), 2)))
    print('\nstock trajectory (mean over worlds) at steps 0,16,32,63,96,127,160,255:')
    for name in C:
        for reg in 'NDW':
            st = R[(name, reg)][2].mean(1)
            print('  %-6s %s %s' % (name, reg, ' '.join('%5.1f' % st[k] for k in [0, 16, 32, 63, 96, 127, 160, 255])))
    print('\ncentre CPU s:', round(time.process_time() - t0, 1))
    # ---- sensitivity: action cost / inverse temperature ----
    for cost, beta in [(3.0, 1.0), (2.0, 1.0), (1.0, 3.0)]:
        print('\n===== SENSITIVITY cost=%g beta=%g (100 worlds) =====' % (cost, beta))
        Rs = table(truths + truths2, ['N', 'D', 'W'], cost=cost, beta=beta, label='c%g b%g' % (cost, beta), nw=100)
        classify(Rs, [t[0] for t in truths + truths2], 'c%g b%g' % (cost, beta))
        for name in ['DULL', 'SHARP', 'DULL.02', 'SHARP.02']:
            print('  %s under N: pi_t!=pi share %.3f' % (name, Rs[(name, 'N')][4].mean()))
    hi = hyp_index('ONE', 12, 1, 0.0)
    post, stock, acts, pidev, LL = run(hi, 'N', 3, cost=3.0, nw=100)
    P = np.exp(LL - safe_lse(LL, 1)[:, None])
    print('\nCHECK cost=3, truth ONE(12,1), N, 256 steps: mean posterior on exact truth hyp %.2f, on theta=12 %.2f, on pi=1 %.2f, MAP==truth %.2f'
          % (P[:, hi].mean(), P[:, TH == 12].sum(1).mean(), P[:, PI == 1].sum(1).mean(), np.mean(LL.argmax(1) == hi)))
    print('\ntotal CPU s:', round(time.process_time() - t0, 1))
