import json
from collections import Counter
from itertools import combinations
import numpy as np
import pytest
from ghostscale.validation.soundingline.v18_3 import world as W,neural_data as D


def test_features_reject_truth_and_ignore_evaluator_changes():
    w=W.make_world(0,98765);h=D.history(w,1,W.rng('feature-control'),8)
    payload=W.packet(w,h);x,n,wf=D.features(payload)
    assert x.shape[0]==32 and n==8 and np.all(x[8:]==0)
    bad=json.loads(payload);bad['future']=[1,2,3]
    with pytest.raises(ValueError):D.features(W.canonical(bad))
    assert np.array_equal(x,D.features(payload)[0])


def test_balanced_withheld_combinations_and_predictive_alias():
    states=[W.STATES[i] for i in D.NEURAL_STATES if D.parity(i)==0]
    assert len(states)==8
    for a,b in combinations(range(4),2):assert set(Counter((s[a],s[b]) for s in states).values())=={2}
    checks=D.predictive_check(W.make_world(0,98765))
    assert checks[0]['new_query_span_residual']>1e-5
    assert not checks[0]['sufficient_for_declared_updates']
