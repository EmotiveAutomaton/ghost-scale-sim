# Complete V18 scientific replay

Contains evaluator truth. Extract, then run from this directory using the project's Python interpreter:

`python -B -m runners.report_v18 --root run --output reproduced --replay`

Uses only the standard library. No installation, old campaign stage or hidden raw archive is needed.
