# Prospective packet protocols

## P1: purpose portfolios and old-task tie rules

Use the eight binary observation histories from V18.3 and all 4,140 deterministic
partitions. Each new coefficient draw is crossed with the 16 existing architecture
settings; a separate lexicographic rule is a severity arm. Cardinalities are 1, 2,
4 and 8. Compare canonical numerical-old-optimum, seeded random old optimum,
maximum-code-entropy old optimum, old-optimal observation-bit product, average
training-purpose objective, and minimum worst training-purpose regret.

The training portfolio contains the passive question, goal=0 and signal=0. Held-out
purposes are goal=1, signal=1, goal=0/signal=1, goal=1/signal=0 and a changed
budget/price composition. All decoders use the supplied finite law; this measures
information retained by a code, not learned decoding. Portfolio selection has
additional declared training-purpose access, while old-only methods do not.
No selector receives held-out losses. Numerical equivalence uses 1e-10. Maximum
storage and actual code entropy are separate reported costs.

Reweight the history prior through a declared exponential tilt of the binary
observation count, selected before outcomes, to test sensitivity to deployment
frequencies. Fit all codebooks under the original history prior; refit only the
generator-informed deployment decoder under the tilted prior. Independent scalar
loss checks cover every selected code. One-symbol and eight-symbol equivalence,
uniform-null ties, monotone optimum and future-label noninterference are gates.

## L1: support, query diversity and learning budget

Retain direct, flat-GRU and three-slot-GRU architectures and equal full simulator
distribution supervision. New count-matched training samples cover the even
latent combinations, the odd combinations, or all positive-skill combinations.
The count is histories per architecture cell, not per latent combination.
World draws, lengths and total query rows remain matched across support arms.

Old-only supervision uses the original five training questions. Diverse supervision
uses a fixed, seeded five-of-eight question rotation, with equal total labels;
the three added question types must be called covered in that arm. A farther
budget/price/goal/signal composition remains absent from both training and
development. Development shares the selected support/query regime. Test data and
exact references remain evaluator-only; all methods receive identical public data.

The initial ladder varies widths, history count and optimization duration in
separate packets with explicit matched contrasts. These are learning curves and
diagnostic interventions, not additional independent worlds. Checkpoint and
capacity selection use development only. Zero-skill exclusion is explicit;
the exact reference still uses the declared full finite prior.

Next reviews may admit observable-bank objectives, sufficient-state distillation,
nonlinear selective readouts and prefix credit-assignment tests after their own
known-answer gates. They are not silently treated as implemented by this protocol.
