"""Run inside extracted packet source; independently regroup and replay outputs."""
import argparse
import gzip
import json
import math
import os
from pathlib import Path
import time
import numpy as np
from ghostscale.validation.soundingline.v18_3.io import read,write,file_digest,canonical


def budget():
    from datetime import datetime,timezone
    if 'GHOST_VERIFY_DEADLINE' in os.environ and datetime.now(timezone.utc)>=datetime.fromisoformat(os.environ['GHOST_VERIFY_DEADLINE']):raise TimeoutError('absolute verification deadline')
    if time.process_time()>=float(os.environ.get('GHOST_VERIFY_CPU_LIMIT','inf')):raise TimeoutError('verification CPU allowance')


def finite(root):
    from ghostscale.validation.soundingline.v18_4 import runtime as R
    complete=read(root/'COMPLETE.json');summary=read(root/'SUMMARY.json');groups={};units=[]
    for block in complete['blocks']:
        budget()
        for unit in R.load(root,block):
            units.append(unit)
            dimensions=('family','cell','rule','tilt') if unit['family']=='P' else ('family','cell','condition','length','copy_span')
            metrics=('old_loss','new_loss','entropy_nats','old_optimum_ties') if unit['family']=='P' else ('expected_loss','pre_change_loss','post_change_loss','expected_match','abstention_loss')
            for row in unit['rows']:
                tags={k:unit.get(k) for k in dimensions};tags['method']=row['method']
                if 'cardinality' in row:tags['cardinality']=row['cardinality']
                key=canonical(tags).decode()
                for metric in metrics:groups.setdefault((key,metric),[]).append(float(row[metric]))
    for (key,metric),values in groups.items():
        item=summary['cells'][key][metric]
        if item['n']!=len(values) or abs(math.fsum(values)/len(values)-item['mean'])>1e-10:raise ValueError('independent mean differs')
    indices=sorted({int(i*(len(units)-1)/7) for i in range(8)})
    for i in indices:
        budget()
        if json.loads(canonical(R.dispatch(units[i]['request'])))!=units[i]:raise ValueError('whole-unit replay differs')
    return dict(units=len(units),independent_means=len(groups),whole_unit_replays=indices)


def neural(root,output):
    from ghostscale.validation.soundingline.v18_3 import torch_worker as T
    import torch
    raw=json.loads(gzip.decompress((root/'neural_points.json.gz').read_bytes()));summary=read(root/'SUMMARY.json')
    grouped={};metrics=('expected_loss','brier','total_variation')
    for row in raw['rows']:
        key=(row['condition'],row['method'],row['lineage'])
        for metric in metrics:
            value=row[metric]
            if isinstance(value,dict):value=None if value['infinite'] else value['value']
            grouped.setdefault(key,{}).setdefault(metric,[]).append(value)
    def mean(v):return None if any(x is None for x in v) else math.fsum(v)/len(v)
    clusters={k:{m:mean(v) for m,v in a.items()} for k,a in grouped.items()};checked=0
    for key,reported in summary['cells'].items():
        condition,method=key.split('|');selected=[a for k,a in clusters.items() if k[:2]==(condition,method)]
        for metric in metrics:
            expected=mean([a[metric] for a in selected]);actual=reported[metric]
            if actual['n']!=len(selected):raise ValueError('lineage count differs')
            if expected is None:
                if actual['mean'] is not None:raise ValueError('missing mean differs')
            elif abs(expected-actual['mean'])>1e-10:raise ValueError('independent neural mean differs')
            checked+=1
    complete=read(root/'neural/COMPLETE.json');inputs=read(root/'data/reader/INPUTS.json');replays=[]
    scratch=output.parent/'forecast-replay';scratch.mkdir(exist_ok=True)
    for reader,predictions in complete['predictions'].items():
        for condition,entry in predictions.items():
            budget()
            data=T.dataset(root/'data/reader'/inputs['tests'][condition]['name'])
            indices=torch.as_tensor(np.linspace(0,len(data['sample'])-1,64,dtype=np.int64))
            used=torch.unique(data['sample'][indices],sorted=True)
            inverse=torch.full((len(data['history']),),-1,dtype=torch.long);inverse[used]=torch.arange(len(used))
            subset=dict(history=data['history'][used],length=data['length'][used],query=data['query'][indices],sample=inverse[data['sample'][indices]])
            path=scratch/f'{reader}-{condition}.npz'
            T.forecast(root/'neural'/entry['selected']/'BEST.pt',subset,path)
            with np.load(path,allow_pickle=False) as z,np.load(root/'neural'/entry['file'],allow_pickle=False) as original:
                error=float(np.max(abs(z['probabilities']-original['probabilities'][indices.numpy()])))
            if error>2e-6:raise ValueError('forecast replay differs')
            replays.append(dict(reader=reader,condition=condition,probes=64,max_absolute_error=error))
    if torch.cuda.is_initialized():raise ValueError('unexpected CUDA')
    return dict(independent_means=checked,lineage_clusters=len(clusters),forecast_replays=replays)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();root=args.root;source=Path(__file__).resolve().parents[1]
    if os.name=='nt':
        import ctypes
        ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(),0x4000)
    budget()
    write(args.output.parent/'REPLAY-STATUS.json',dict(pid=os.getpid(),parent_pid=os.getppid()),immutable=False)
    plan=read(root/'PLAN.json');complete=read(root/'COMPLETE.json')
    if any(file_digest(source/name)!=sha for name,sha in plan['sources'].items()):raise ValueError('extracted scientific source differs')
    if file_digest(root/'SOURCE.zip')!=plan['source_archive_sha256']:raise ValueError('source archive differs')
    if plan['design']['engine']=='neural':
        for name,sha in complete['files'].items():
            if file_digest(root/name)!=sha:raise ValueError('retained neural artifact differs')
        checked=neural(root,args.output)
    else:
        if complete['summary_sha256']!=file_digest(root/'SUMMARY.json'):raise ValueError('summary changed')
        checked=finite(root)
    write(args.output,dict(passed=True,plan_sha256=file_digest(root/'PLAN.json'),summary_sha256=file_digest(root/'SUMMARY.json'),
        verifier_sha256=file_digest(Path(__file__)),checks=checked,cpu_seconds=time.process_time(),
        scope='all retained means; eight evenly spaced whole-unit replays or 64 forecast rows per reader/test from extracted source; not full retraining'))


if __name__=='__main__':main()
