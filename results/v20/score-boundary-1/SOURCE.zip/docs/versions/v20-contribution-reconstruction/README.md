﻿# V20 contribution reconstruction

Implementation approved 27 September 2026. The fixed finish is Friday 2 October
at 05:00 Pacific (12:00 UTC). The scientific cutoff is Thursday 1 October at
21:00 Pacific, with eight hours reserved for review, export and delivery.

The question is whether structured contribution accounts recover distinctions that
matched direct readers miss, and which distinctions require episode evidence.
These are constructed-method tests, not evidence about private human intent.

- [Execution protocol](PROTOCOL.md): targets, complete G0-G7 consumers, whole-lineage
  splits, controls, resources, finite continuation and reporting.
- [Model registry](MODEL_REGISTRY.json): finite new fit allowance and fixed settings.
- [Original coding package](CODING_PACKAGE.md) and [source provenance](PROVENANCE.json).
- [Historical implementation plan](IMPLEMENTATION_PLAN.md): prepared before approval;
  its planning-only status and rolling-clock proposal are superseded by the protocol.
- [Opening scientific review](OPENING_REPORT.md): failed context primary, separate acquisition/correction findings, full scientific replay.
- [Results and live report index](../../../results/v20/README.md).

One scientific CPU worker and one numerical thread, below normal priority, no GPU
or environment synchronization. V19 keeps its own September 28 final closeout.
Sounding Line retains resource priority. Frozen results, sources and failed attempts
are preserved; named accepted batches are published during the week.
