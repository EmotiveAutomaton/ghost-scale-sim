# V19 asymmetric cue response - 25 September 2026

We tested whether storage choices remain robust when cue mistakes favor a particular wrong label. Guarding against directional errors lowers worst expected regret in 143 of 420 problems relative to the symmetric-error policy, and improves on fixed storage in four. Independent reconstruction and both full replays verify this constructed-method result; forecast accuracy and process correspondence remain unestablished.

V19 remains active with 113 independently accepted scientific batches. Asymmetric cue errors are independently verified. Conditional second-cue acquisition is implemented and undergoing admission; unknown cue dependence and mistaken-dependence acquisition remain prepared alternatives. Earlier timing blockers and fixture failures remain retained. The immutable interim population remains 92; twenty-one later acceptances are dated separately. Protected lineages, the 16-hour reserve and final time are unchanged.

[Report](../versions/v19-local-maker/ASYMMETRIC_CHANNEL_REPORT.md).
