# Fixed-byte retention execution and replays verified

We tested whether equal source counts conceal unequal memory costs. All 1,064 deterministic outputs match both complete replays; independent numerical reconstruction and paired regroup remain pending. This is a supplied-law constructed-method test, with no established learned provenance, historical process correspondence or human intent.

All exports are scientific/evaluator evidence. Numerical reconstruction and separate regroup remain pending.
