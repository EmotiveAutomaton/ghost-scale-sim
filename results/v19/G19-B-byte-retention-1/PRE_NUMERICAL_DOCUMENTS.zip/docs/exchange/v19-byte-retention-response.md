# V19 fixed-byte retention

We tested whether equal source counts conceal unequal memory costs. All 1,064 deterministic outputs match both complete replays; independent numerical reconstruction and paired regroup remain pending. This is a supplied-law constructed-method test, with no established learned provenance, historical process correspondence or human intent.

V19 remains active with 87 independently accepted scientific batches. Fixed-byte retention execution and both complete replays are verified. Its independent checker passed 104 isolated controls and was observed executing through the existing serial queue. Highest-probability source retention and aggregate single-report state remain prepared alternatives; query-announced retention remains timing-blocked after one identified repair. Earlier timing blockers and A3/C2/F2 prerequisites are unchanged.

[Report](../versions/v19-local-maker/BYTE_RETENTION_REPORT.md).
