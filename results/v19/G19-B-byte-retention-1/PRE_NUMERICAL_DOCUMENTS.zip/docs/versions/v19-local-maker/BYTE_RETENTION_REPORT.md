# Fixed-byte retention: execution and independent review

We tested whether equal source counts conceal unequal memory costs. All 1,064 deterministic outputs match both complete replays; independent numerical reconstruction and paired regroup remain pending. This is a supplied-law constructed-method test, with no established learned provenance, historical process correspondence or human intent.

V19 remains active with 87 independently accepted scientific batches. Fixed-byte retention execution and both complete replays are verified. Its independent checker passed 104 isolated controls and was observed executing through the existing serial queue. Highest-probability source retention and aggregate single-report state remain prepared alternatives; query-announced retention remains timing-blocked after one identified repair. Earlier timing blockers and A3/C2/F2 prerequisites are unchanged.

For each source roster, the two byte budgets are the lesser costs of original
recent and exact-midpoint half/quarter selections. Each source costs its mixed
float masses plus integer metadata and structural group/past-state indices.
Shared overhead includes group masses, the full copy histogram, forgotten-context
counts and one prior table. Recency visits decreasing times; midpoint priority
visits its original midpoint selection in increasing time, then remaining times
in decreasing order. Each policy skips unaffordable sources and continues.
Equal budgets can retain different source counts. The budget labels describe
their construction, not an asserted retained fraction.

All 28,672 posteriors, 505,856 source candidates, 143,360 summary rows and
1,146,880 report queries remain. Eight laws, two evidence conditions, two draws,
seven structural cells, five copying probabilities and eight endpoint reports
stay paired. Each draw has all 128 Cartesian identities. The 48 unavailable
checkpoint strata remain absent. All 65 metrics, exact support masks and undefined
errors are retained. Every omitted source keeps its original uniform probability
in the original uniform sixteen-maker-prior remainder. No fitted model, new
observation or protected lineage is used.

All 1,064 deterministic outputs match original, adjacent and extracted-source
executions. All 894 source files, 164
inputs, plans, environment and separately bound timings verify. Complete outputs
are preserved in 14 scientific/evaluator archives; reader inputs are
unchanged. Reproduction does not yet establish independent numerical acceptance.

The independent checker recounts storage using explicit structural sets and
selects exact rational midpoint ranks. It rebuilds both greedy selections and
checks used/unused byte identities without assuming equal retained counts.
Independent bit schedules and direct joint group/report Bayes numerators rebuild
all future coordinates. Explicit expected one-hot squared losses check regret
against squared probability distance. It imports no producer selector, evaluator,
summarizer, transition operator or posterior-direction kernel. Reference timing
does not measure optimized compact-state latency.

All 104 isolated producer/checker/runtime/portable controls pass, with no
failures, skips or warnings. They include equal budgets with unequal source counts,
empty/full selection, dense/sparse/constant/disjoint laws, source permutations,
every raw-field and undefined-mask corruption, malformed frozen designs, complete
native integration and output/roster/timing corruption. Absolute tolerance stays
one trillionth. Full-support synthetic timing covers all seven structures and
both source densities with three archived 32-row batches per shape.
Conservative reconstruction allowance is 874.50
CPU seconds; inclusive admission is 2229.73
of 3,600, including prior attempts, all three executions, checks, reconstruction,
150 seconds for separate regroup and 200 seconds for operations. All
897 checker sources and 1066 inputs are frozen.
The existing serial queue was observed executing this checker below normal.

Acceptance requires its completion and a separate standard-library regroup of
ORIGINAL rows into 1,120 draw strata, 560 law strata and 70 population cells for
all 65 metrics and both budget-paired contrasts. Two draws stay within eight equally
weighted laws; source/report multiplicity is not independent replication. Do not
assume matching counts. No practical margin or confirmatory interval was frozen.
This is a supplied-law constructed method, miniature - architecture untested
beyond the retained roster. Learned provenance, historical process correspondence
and human intent remain unestablished.

A1's accepted eight-law/two-fit/equal-four-class regroup and portable replay bindings
reverify. G19-04/G19-05/B1/D1/D2 remain complete; both tiny settings are consumed.
Highest-probability retention and aggregate single-report state are prepared,
unimplemented and unadmitted alternatives. Query-announced retention remains
timing-blocked after one identified repair; other timing blockers and A3/C2/F2
prerequisites remain. No exhaustion is claimed. Resource ceilings, protected
lineages and immutable interim/final times remain unchanged.

[Frozen contract](RETENTION_BYTE_BUDGET_PROTOCOL.md).
[Independent protocol](BYTE_RETENTION_REVIEW_PROTOCOL.md).
[Execution review](../../../results/v19/G19-B-byte-retention-1/EXECUTION_REVIEW.json).
[Evidence roles](../../../results/v19/G19-B-byte-retention-1/EXECUTION_EVIDENCE_ROLES.json).
