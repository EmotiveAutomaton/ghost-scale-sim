# Provenance restoration after repeated evidence: prepared alternative

Can correcting source identity restore the appropriate current-state account
after copied evidence has been counted repeatedly? This prepared B/D alternative
has no implemented handler or admitted job.

Use only saved midpoint/stationary streams from G19-B-unknown-change-1, the five
frozen filters, both lengths, draws, reference factors and all sixteen makers
within eight original lineages. No new observations or fits. Begin with supplied
distinct identities. At each original checkpoint independently compare full
recomputation after true identity restoration, continued omission, a label-only
rename that retains distinctness, and the original identity-aware control. A
correction gives provenance information, not additional endpoint observations.

Full recomputation must exactly recover the original control, including reset
selection by distinct source. The label-only control must preserve omission.
These are apparatus identities, not new empirical benefits. The scientific
question is the size and direction of correction effects across score and
uncertainty measures. Preserve before/after source assignments, current-state
joint weights, all five measures and every original stratum. Average makers
within draw, then both draws within paired coefficient lineage; report 10,000
resamples with seed 190501, draw means and the 0.02-nat loss margin. Do not treat
duplicate reference streams as independent evidence.

Controls must reject source conflicts, verify undoing a counted-twice likelihood,
neutral laws, no effect on independent sources, timestamp preservation and
complete reset-history reconstruction. Reader corrections contain observed
source equivalences only; true maker, switch labels, laws and scores stay
evaluator-only. Retain original/adjacent/extracted-source replay and independent
products. A four-hour cap includes all work within family/global limits. Freeze
source and roster before outcomes. This is deterministic provenance revision
under supplied laws, not learned trust or human intent. Changed-primitive
feedback remains an independent prepared alternative.
