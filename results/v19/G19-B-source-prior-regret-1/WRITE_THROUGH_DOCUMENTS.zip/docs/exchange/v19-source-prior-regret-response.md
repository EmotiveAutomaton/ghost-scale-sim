# V19 source-prior regret response — 25 September 2026

We tested whether protecting against missed source probability favors the same storage as maximizing minimum coverage. Minimizing worst regret changes seven of 28 distinct choices; each change reduces worst regret but lowers minimum retained mass. Independent rational reconstruction, all 57,344 rows and both complete replays verify this constructed-method tradeoff. Forecast accuracy, learned provenance, historical process correspondence and human intent remain unestablished.

V19 remains active with 98 independently accepted scientific batches. Source-prior regret is independently verified. Precision-choice stability and randomized source storage remain prepared alternatives. The immutable interim population remains 92; six later acceptances are dated separately. Protected lineages, the 16-hour reserve and final time are unchanged.

[Report](../versions/v19-local-maker/SOURCE_PRIOR_REGRET_REPORT.md).
