# V19 cue acquisition cost response - 25 September 2026

We tested when paying for a source cue ceases to improve storage. With a cue that is correct two-thirds of the time, acquisition has positive net value in 147 of 420 problems when free, 125 at a fee of 1/64, and 34 at 1/16; none benefits at 1/4. Fees are hypothetical source-probability utility. Independent rational reconstruction and both full replays verify this constructed-method result; forecast accuracy and process correspondence remain unestablished.

V19 remains active with 111 independently accepted scientific batches. Cue acquisition cost is independently verified. Repeated cue dependence is implemented and undergoing admission; asymmetric cue errors and unknown cue dependence remain prepared alternatives. Earlier timing blockers and fixture failures remain retained. The immutable interim population remains 92; nineteen later acceptances are dated separately. Protected lineages, the 16-hour reserve and final time are unchanged.

[Report](../versions/v19-local-maker/CUE_ACQUISITION_COST_REPORT.md).
