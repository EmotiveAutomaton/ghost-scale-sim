"""Portable replay driver; run against an extracted, matching SOURCE.zip."""
import os
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[key]='1'
import argparse
from datetime import datetime,timezone
from pathlib import Path
import sys
import time


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--packet',type=Path,required=True);parser.add_argument('--source',type=Path,required=True)
    parser.add_argument('--retained-root',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--cpu-limit',type=float,default=7200)
    args=parser.parse_args();sys.path.insert(0,str(args.source.resolve()))
    from ghostscale.validation.soundingline.v18_3.io import read,write,file_digest
    from ghostscale.validation.soundingline.v18_4.priority import below_normal
    from ghostscale.validation.soundingline.v19.runtime import fingerprint,REPO
    below_normal();start=time.process_time();plan=read(args.packet/'PLAN.json')
    if REPO.resolve()!=args.source.resolve():raise ValueError('matching extracted source was not imported')
    if plan['environment']!=fingerprint():raise ValueError('replay environment differs')
    if any(file_digest(args.source/n)!=h for n,h in plan['sources'].items()):raise ValueError('replay source differs')
    args.output.mkdir(parents=True,exist_ok=False)
    def pulse(**details):
        if time.process_time()-start>=args.cpu_limit:raise TimeoutError('replay CPU budget')
    kind=plan['design']['handler']
    if kind=='certify':from ghostscale.validation.soundingline.v19.retained import certify as handler
    elif kind=='packet-zero':from ghostscale.validation.soundingline.v19.retained import packet_zero as handler
    elif kind=='local-world':from ghostscale.validation.soundingline.v19.local_world import admission as handler
    elif kind=='state-error':from ghostscale.validation.soundingline.v19.state_error import run as handler
    elif kind in ('readout-scout','local-primary'):from ghostscale.validation.soundingline.v19.readouts import run as handler
    elif kind in ('frame','jointness'):from ghostscale.validation.soundingline.v19.local_alternatives import run as handler
    else:raise ValueError('unsupported replay handler')
    effective=dict(plan,design=dict(plan['design'],retained_root=str(args.retained_root.resolve())))
    summary=handler(args.output,effective,pulse);write(args.output/'SUMMARY.json',summary)
    expected=read(args.packet/'COMPLETE.json')['files']
    if (args.packet/'EVALUATOR_MANIFEST.json').exists():expected.update(read(args.packet/'EVALUATOR_MANIFEST.json')['files'])
    for name,sha in expected.items():
        if file_digest(args.output/name)!=sha:raise ValueError('replay differs: '+name)
    write(args.output/'REPLAY.json',dict(passed=True,files=expected,cpu_seconds=time.process_time()-start))
    print('V19 portable replay passed:',len(expected),'output identities')


if __name__=='__main__':main()
