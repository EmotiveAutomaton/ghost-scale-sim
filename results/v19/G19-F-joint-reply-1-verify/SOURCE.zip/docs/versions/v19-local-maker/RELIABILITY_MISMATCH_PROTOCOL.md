# Misstated reply reliability: prepared independent alternative

Can a reader benefit from a noisy mechanical reply when its stated accuracy is
wrong? Keep the retained 640 queries, eight development laws, both tool rules,
native and uniform legal conditional laws, and native and equal-query scoring
populations. Request skill or belief once, separately. Cross actual accuracies
0.5, 0.75 and 1 with assumed accuracies 0.5, 0.75 and 1, enumerating both replies.
No request and correctly calibrated conditioning are fixed references. Do not
select the field or the assumed accuracy from truth or observed losses.

Retain actual reply probabilities separately from the assumed likelihoods,
all forecast vectors, zero-modeled-mass fallbacks, endpoint proper scores,
infinite-loss mass, ambiguity and request counts. Charge prices 0, 0.02 and
0.1 nats per return. The reader receives visible artifacts and operations,
requested field, reported bit and stated accuracy only. Actual accuracy,
hidden fields, law weights, endpoint truth and scores remain evaluator-only.

Before any execution freeze a handler, complete enumeration and source after
known scalar odds, half-channel identity, truthful-parent identity, explicit
zero-support/infinity and corruption controls. Require both complete replays
and independent scalar reconstruction before numerical acceptance. Paired law
intervals condition on the fixed roster; no fitting, new episode or protected
lineage is allowed. This is a supplied-law calibration method, not evidence
about human testimony, historical process correspondence or learned access.

This alternative is prepared and unimplemented. Its half-hour CPU ceiling
includes tests, science, replays, review and failures within F and the global
allocation. It is independent of joint-field dependence and retrospective
quotient updating; neither must win to release it. A completed calibrated
diagonal is an identity reference, never a new replicated discovery.
