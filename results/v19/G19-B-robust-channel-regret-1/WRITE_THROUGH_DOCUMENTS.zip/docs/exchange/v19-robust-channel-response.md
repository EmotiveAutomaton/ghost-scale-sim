# V19 robust-channel response - 25 September 2026

We tested whether guarding against uncertain cue reliability improves storage beyond the policy chosen for two-thirds reliability, and found no reduction in worst expected regret in these 420 problems. It improves on fixed storage in 147. Independent rational reconstruction and both full replays verify this constructed-method result; forecast accuracy and process correspondence remain unestablished.

V19 remains active with 107 independently accepted scientific batches. Robust channel regret is independently verified. Precision-choice stability and randomized channel regret remain prepared alternatives; neither is yet admitted. The immutable interim population remains 92; fifteen later acceptances are dated separately. Protected lineages, the 16-hour reserve and final time are unchanged.

[Report](../versions/v19-local-maker/ROBUST_CHANNEL_REGRET_REPORT.md).
