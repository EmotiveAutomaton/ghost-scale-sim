# V19 partial-prior response - 25 September 2026

We tested whether partial disclosure of the source prior improves retained coverage. It improves expected retained mass in 348 of 1,260 distinct partial-disclosure problems, capturing the full-disclosure benefit in 342. Independent rational reconstruction verifies all 57,344 roster rows, their 4,300,800 disclosure evaluations and both complete replays. This is a constructed-method result about gross information value in a finite storage library; it does not establish forecast accuracy or process correspondence.

V19 remains active with 103 independently accepted scientific batches. Partial prior disclosure is independently verified. Precision-choice stability and noisy prior disclosure are prepared alternatives. The immutable interim population remains 92; eleven later acceptances are dated separately. Protected lineages, the 16-hour reserve and final time are unchanged.

[Report](../versions/v19-local-maker/PARTIAL_PRIOR_REPORT.md).
