from pathlib import Path
import os,sys,time,json,zipfile,hashlib,shutil
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
repo=Path.cwd();c=repo.parent/'.local/v19';ad=json.loads((c/'ROBUST_REVIEW_TEST_ADMISSION_175796.json').read_text());sys.path.insert(0,ad['isolated_source'])
from ghostscale.validation.soundingline.v18_3.io import read,write,file_digest as sha,now
from ghostscale.validation.soundingline.v19 import robust_precision_review as M,runtime as R
R.below_normal();start=time.process_time();state='failed';name='G19-B-robust-context-precision-1';root=c/name;out=repo/'results/v19'/name
try:
 assert read(c/'QUEUE-STATUS.json')['state']=='awaiting_review_refill'
 plan=read(root/'PLAN.json');assert plan['environment']==R.fingerprint()
 original=read(root/'COMPLETE.json');replays=[]
 for job in read(c/'PRECISION_PREPARED_QUEUE_23924.json')['jobs']:
  r=Path(job['root']);receipt=read(r/'COMPLETE.json')
  assert job['plan_sha256']==sha(r/'PLAN.json')==sha(root/'PLAN.json')==receipt['plan_sha256']
  assert sha(r/'SOURCE.zip')==plan['source_archive_sha256']
  assert all(sha(Path(job['source'])/n)==h for n,h in plan['sources'].items())
  with zipfile.ZipFile(r/'SOURCE.zip') as z:assert {n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}==plan['sources']
  assert all(sha(r/n)==h for n,h in receipt['files'].items())
  assert all(sha(r/'inputs'/n)==h for n,h in plan['design']['input_files'].items())
  assert receipt['files']==original['files']
  replays.append(dict(job=r.name,complete_sha256=sha(r/'COMPLETE.json'),all_output_bytes_equal=True,source_files_verified=len(plan['sources'])))
 assert sha(out/'PLAN.json')==sha(root/'PLAN.json') and sha(out/'SOURCE.zip')==sha(root/'SOURCE.zip')
 parent=c/'G19-B-law-rounding-envelope-1';assert sha(parent/'PLAN.json')==plan['design']['parent_plan_sha256']
 for n,h in plan['design']['input_files'].items():assert sha(parent/'inputs'/n)==h
 assert all(read(root/'CONTROLS.json').values())
 result=M.verify(root)
 result.update(at=now(),plan_sha256=sha(root/'PLAN.json'),source_archive_sha256=sha(root/'SOURCE.zip'),environment=plan['environment'],environment_verified=True,replays=replays,review_tests='35 isolated controls passed',review_source_sha256=sha(Path(ad['isolated_source'])/'ghostscale/validation/soundingline/v19/robust_precision_review.py'),reader_inputs='none',limitations='Uniform supplied-law bound for same prior and transitions;not attained error or reachable extrema;no learned access,process correspondence or human intent')
 write(out/'INDEPENDENT_REGROUP.json',{k:result[k] for k in ('law_strata','equal_law_cells','original_rows','checks')})
 compact={k:v for k,v in result.items() if k!='law_strata'};compact.update(law_strata=len(result['law_strata']),independent_regroup_sha256=sha(out/'INDEPENDENT_REGROUP.json'))
 write(out/'NUMERICAL_REVIEW.json',compact)
 for n in ('COMPLETE.json','SUMMARY.json','CONTROLS.json','EVIDENCE_ROLES.json'):shutil.copyfile(root/n,out/n)
 for suffix,label in [('-replay','ADJACENT_REPLAY.json'),('-portable','PORTABLE_REPLAY.json')]:shutil.copyfile(c/(name+suffix)/'COMPLETE.json',out/label)
 with zipfile.ZipFile(out/'SCIENTIFIC.zip','x',zipfile.ZIP_DEFLATED) as z:
  for n in original['files']:z.write(root/n,n)
  z.write(root/'COMPLETE.json','COMPLETE.json')
 with zipfile.ZipFile(out/'REVIEW_SOURCE.zip','x',zipfile.ZIP_DEFLATED) as z:
  for n in ('ghostscale/validation/soundingline/v19/robust_precision_review.py','tests/test_v19_robust_precision_review.py'):z.write(Path(ad['isolated_source'])/n,n)
  z.write(ad['test_log'],'controls.log')
 write(c/'ROBUST_REVIEW_175796.json',dict(at=now(),passed=True,review_sha256=sha(out/'NUMERICAL_REVIEW.json'),card_cpu_before=R.card_consumed(c,plan['design'],'')))
 print(json.dumps(compact));state='complete'
finally:write(c/'attempts/robust-independent-review-175796-2.json',dict(packet='robust-independent-review-175796',accounting_card='G19-B-robust-context-precision',state=state,cpu_seconds=time.process_time()-start))
