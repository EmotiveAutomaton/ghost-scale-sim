# Joint process readout: execution complete, verification pending

Does a learned predictive bank help recover the maker’s complete local goal-and-operation sequence? The joint readout execution is complete, but its numerical conclusion awaits independent reconstruction and both full replay comparisons. Original source, output and reader-role integrity verify. This is a constructed-method comparison; no new accuracy advantage, historical process correspondence or human-intent claim is accepted yet.

The frozen comparison uses 32 training and 16 development coefficient lineages,
two interleaved training draws, five paired random-feature seeds and nested
32/128/512/2,048-path budgets in four evidence conditions. It retains 480 fitted
target heads, 10,240 lineage/fit/budget/arm score records and 912 anonymous public
packets. All 2,023 deterministic output identities, the separate timing record,
original source archive, frozen source files, plan and environment verify.
This integrity check does not accept the reported numerical scores.

Complete three-step goal/operation labels occupy a fixed 5,832-tuple syntactic
universe. Each head learns only its training-prefix alphabet; the declared unknown
mass is spread over the remaining tuples without consulting development truth.
Every learner receives the same target labels and 2,048 auxiliary observable
outcome distribution labels. Capacity counts match across target heads while
representation geometry differs. The exact reference has supplied-law privilege.
Feature seeds are not independent tiny-model fits, and the two training draws
do not establish universal training-population uncertainty.

The [independent checker](JOINT_REVIEW_PROTOCOL.md) reconstructs native paths and
weights, training selections, labels, public features, auxiliary models, saved
softmax forecasts and gradients, all process metrics and paired learning-curve
areas. Its source and inputs are frozen. Known-answer tests execute before outcome
access in the single scientific queue; they are not claimed passed at admission.
Separate complete adjacent and extracted-source replays check reproducibility.
Discrete candidate and modal decisions are checked on the saved probabilities
after numerical reconstruction, preserving the actual tie ordering.

The reader archive contains only anonymous visible evidence at the declared tier.
Training supervision is separately identified. Native states, actual goals,
pairing identities, exact posteriors, fitted models, forecasts and scores remain
scientific/evaluator material. A model's candidate distribution is an output,
never reader evidence. The full raw outputs remain retained and hash-bound while
the accepted scientific export awaits numerical adjudication.

**Warrant:** verification pending, exploratory constructed method; miniature —
architecture untested. Neither completion nor a good numerical score establishes
historical uniqueness or human intent. Solver success and achieved gradient
tolerance require separate review, as do joint compatibility and localization.

**Pursuit:** finish the independent reconstruction and both replays, classify the
paired contrasts, and make a separate sensitivity/confirmation decision on the
untouched reserved populations. The implemented crossed-rule and support/holdout
alternatives retain their independent regression prerequisites. The regression
barrier passed 116 Ghost tests but its Torch collection failed because two modules
configured interop threads. A new launcher snapshot makes the scientific module
the sole initializer; full regression remains required before successor release.
No completed scientific experiment is restarted by this engineering repair.

[Execution and role receipt](../../../results/v19/G19-05-joint-readout-1/EXECUTION_REVIEW.json)
and [frozen scientific protocol](JOINT_READOUT_PROTOCOL.md).
