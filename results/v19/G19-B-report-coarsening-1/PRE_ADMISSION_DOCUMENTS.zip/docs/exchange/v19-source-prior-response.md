# V19 source-prior misspecification

We tested whether assuming equal source probabilities distorts forecasts when reports favor earlier or later observations. With a half chance of copying, the mean largest future-probability error is 0.00028–0.00159 for later-source selection and 0.00072–0.00256 for earlier-source selection. Independent reconstruction, all 1,120 paired strata and both complete replays verify this supplied-law constructed-method result. Learned provenance, historical process correspondence and human intent remain unestablished.

V19 remains active with 80 independently accepted scientific batches. Source-prior misspecification has complete independent numerical reconstruction and paired regroup. Two-report dependence and report-content coarsening remain prepared alternatives; source disclosure and the prior-conditional reachable rival remain timing-blocked.

[Report](../versions/v19-local-maker/SOURCE_PRIOR_REPORT.md).
