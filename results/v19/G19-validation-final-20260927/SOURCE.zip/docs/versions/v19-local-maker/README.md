# V19: local maker reconstruction and usable predictive state

**Active campaign; final closeout is a separate required state.** The accepted
final endpoint is 28 September 2026 at 13:26:05 UTC / 06:26:05 Pacific. The interim
population is fixed at its September 25 cutoff; later acceptances remain separate.
Use dated primary records and native state for current execution, not old prose.

Latest acceptance: [conditional second-cue acquisition](ADAPTIVE_SECOND_CUE_REPORT.md). The campaign now has 114 accepted batches; final validation and closeout remain required.

[Final preparation and frozen remaining scope](FINAL_PREPARATION.md).

## Read first

- [Original coding package](CODING_PACKAGE.md), [provenance](PROVENANCE.json),
  [accepted allocation](ACCEPTANCE.json) and [opening manifest](OPENING_MANIFEST.json).
- [Interim synthesis](INTERIM_REPORT.md) and [closeout requirements](REVIEW_AND_CLOSEOUT_PLAN.md).
- [Current status](../../../results/v19/CURRENT_STATUS.json),
  [coverage](../../../results/v19/TEST_COVERAGE.json) and [result index](../../../results/v19/README.md).
- [Complete document catalog](CATALOG.md): reports, protocols, implementation
  notes and manifests. A filename does not establish acceptance.

## Navigate by question

| Question | Starting documents |
|---|---|
| What is the local world and what can each reader observe? | [World protocol](LOCAL_WORLD_PROTOCOL.md), [local readout](LOCAL_PRIMARY_REPORT.md) |
| Does a representation help recover goals and process? | [Joint readout](JOINT_READOUT_REPORT.md), [matched public support](JOINT_SUPPORT_REPORT.md) |
| What historical information does compression lose? | [Process sufficiency](PROCESS_SUFFICIENCY_REPORT.md), [aggregate report state](AGGREGATE_REPORT_STATE_REPORT.md) |
| Does learned execution transfer? | [Held-out composition](SUPPORT_HOLDOUT_REPORT.md), [changed tools](SUPPORT_TRANSFER_REPORT.md) |
| What does additional or fallible evidence buy? | [Asymmetric cues](ASYMMETRIC_CHANNEL_REPORT.md), [conditional second-cue protocol](ADAPTIVE_SECOND_CUE_PROTOCOL.md) |
| Which claims are supported, qualified or open? | [Theory store](../../theory/READING_INTENT.md), [findings](../../../FINDINGS.md), then the named result review |

## Interpretation and boundaries

Execution, control tests, complete replay, independent numerical acceptance and
confirmation are distinct. Preserve negative results, timing blockers and failed
instruments. Tiny-setting ownership, protected lineages and the accepted resource
ceiling do not reset on queue refill or a documentation pass. Earlier allocations
remain closed.

The [V20 contribution-reconstruction package](../v20-contribution-reconstruction/README.md)
is proposed only and does not amend this campaign. Original V19 specification
bytes remain unchanged. The long former V19 index is preserved in the
[September 27 archive](../../archive/documentation-2026-09-27/README.md); every
individual protocol and report remains at its original path.
