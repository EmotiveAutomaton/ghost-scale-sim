# Joint mechanical replies: prepared independent alternative

Does a reader need the dependence between two noisy fields, even when each
field's marginal reliability is correct? On the retained 640-query roster,
eight development laws and both tool rules, request skill and belief once.
Enumerate all four bit-pair replies at reliability 0.75 under independent
field errors and under one shared flip applied to both fields. Compare the
correct joint likelihood with multiplication of the same marginal likelihoods.
No request and each single-field request are fixed references. No field is
chosen using individual truth or future outcomes.

Keep native and uniform legal conditional laws, native and equal-query
populations, endpoint proper scores, zero-target mass and residual ambiguity
separate. Charge two returns at prices 0, 0.02 and 0.1 nats. Retain all reply
strings, true-channel probabilities, posterior forecasts and explicit zero-mass
fallbacks. Reader inputs expose only artifact, operations, requested fields,
reported bits, marginal reliability and declared joint-source relation;
hidden fields, endpoint truth and conditional laws stay evaluator-only.

Before dispatch freeze the complete finite enumerator, roster and source.
Controls must include identical marginal/different joint channels, known scalar
Bayes posteriors, reliability-half joint-information behavior (a shared flip
can preserve field parity even when each marginal is uninformative), reliability
one identity, constant endpoints, zero support and corrupted reply likelihoods.
Independent numerical reconstruction and both complete replays are required.

This alternative is prepared and unimplemented. Its half-hour CPU cap includes
controls, execution, replays, review and failures within the existing F/global
allocation. No new fit, protected lineage or additional owner is admitted.
It requires no repeated-reply advantage and is independent of retrospective
updating after future-schedule grouping. Its result concerns a supplied-law
information method, not human report reliability or historical intention.
