# Query-context retention: execution and independent review

We tested whether averaging across future query contexts hides different retention errors. All 1,064 deterministic outputs match both complete replays; independent numerical reconstruction and paired regroup remain pending. This is a supplied-law constructed-method test, with no established learned provenance, historical process correspondence or human intent.

V19 remains active with 86 independently accepted scientific batches. Query-context retention execution and both complete replays are verified. Its independent checker passed 128 isolated controls and was observed executing through the existing serial queue. Highest-probability source retention and retention with a query announced before compression remain prepared alternatives. Earlier timing blockers and A3/C2/F2 prerequisites are unchanged.

The comparison preserves the whole future for each of the four legal query
contexts. All five retention states remain: full, recent half/quarter, and evenly
spaced source times at those same counts. Exact rational midpoint ranks select
by time alone. Every source retains its original uniform probability; omitted
likelihoods use an explicit original uniform sixteen-maker-prior remainder.
The copy histogram still includes every source. Equal counts need not mean equal
bytes. All contexts were frozen before outcomes; none is selected for its result.

The complete population has 28,672 posteriors, 505,856 source candidates, 143,360
summary rows and 1,146,880 shared posterior/report queries. Eight laws, two evidence
conditions, two draws, seven structural cells, five copy probabilities and eight
endpoint reports remain paired. Each draw has all 128 Cartesian identities.
All 48 unavailable checkpoint strata remain absent. Ninety metrics preserve fifty
whole-context metrics plus forty context metrics. Unsupported mass, supported
expected squared regret, largest forecast discrepancy and storage remain separate;
undefined raw errors stay NaN. No fit, new observation or protected lineage is used.

All 1,064 deterministic outputs match original, adjacent and extracted-source
executions. All 883 producer sources and 164
input bindings, source archives, plans, environment and separately bound timings
verify. 19 scientific/evaluator archives preserve complete producer
outputs. Reader inputs remain unchanged. Replay establishes reproduction, while
numerical acceptance remains pending.

The independent checker uses direct group/report Bayes numerators, independent
bit schedules and indexed group-state accumulation to reconstruct every future
time, context and endpoint. Explicit expected one-hot squared losses check each
context's regret against squared probability distance. Equal-context mean regret
and maximum-error recombination are checked separately. Structural sets recount
mixed and deterministic storage cells; deterministic cells reuse group weights.
Float64 masses, int32 counts/indices and the shared prior table stay distinct.
It imports no producer evaluator, selector, summarizer, transition operator or
posterior-direction kernel. Reference timing does not measure optimized compact
state latency.

All 128 isolated controls pass without failures, skips or warnings. They
cover dense/sparse/constant/disjoint laws, exact midpoint selection at all counts,
full/copy identities, source and context permutations, all raw-field and undefined-
mask corruptions, summary/pair/roster/timing/input corruption, short futures,
recombination, malformed frozen designs, native integration and portable dispatch.
An intentionally swapped context result preserves the pooled mean but fails the
checker. Absolute tolerance stays one trillionth.

Full-support synthetic timing covers all seven structures and both source
densities with three serialized 32-row batches each, including decompression and
every checker coordinate. The conservative reconstruction allowance is
1024.50 CPU seconds including 50 percent
margin and 180 seconds for input work. Inclusive admission is
2726.56/3600 CPU seconds, including
previous attempts, all three executions, checks, reconstruction, 150 seconds for
original-row regroup and 200 seconds for operations. 887
checker sources and 1066 inputs are frozen. The existing serial queue
was observed running this checker below normal priority. Failed attempts remain
charged; no population was reduced to meet timing.

Numerical acceptance requires completion plus a separate standard-library regroup
of ORIGINAL rows into 1,120 draw strata, 560 law strata and 70 population cells.
Verify all 90 metrics, all paired context/count contrasts and exact identities,
including all fifty inherited metrics against accepted time-retention originals.
Both draws stay inside each of eight equally weighted laws. Reports and contexts
are not independent worlds. No practical margin or confirmatory interval was
frozen. This is a supplied-law constructed method, miniature - architecture
untested beyond this roster. Learned provenance, historical process correspondence
and human intent remain unestablished.

A1's accepted eight-lineage/two-fit/equal-four-class regroup and portable bindings
reverify. G19-04/G19-05/B1/D1/D2 remain complete; both tiny settings are consumed.
Highest-probability source retention and query-announced retention are prepared,
unimplemented and unadmitted. Source-prior retention, two-report dependence,
source disclosure and prior-conditional reachable updating retain timing blockers.
No scope exhaustion is claimed. A3/C2/F2 prerequisites, confirmation lineages,
resource ceilings and immutable reporting times remain unchanged.

[Frozen contract](RETENTION_QUERY_PROTOCOL.md).
[Independent protocol](RETENTION_QUERY_REVIEW_PROTOCOL.md).
[Execution review](../../../results/v19/G19-B-retention-query-1/EXECUTION_REVIEW.json).
[Evidence roles](../../../results/v19/G19-B-retention-query-1/EXECUTION_EVIDENCE_ROLES.json).

The documentary writer stopped on a coverage-container type mismatch after saving
the scientific exports. Its failed attempt and charge are retained; the repair
appends the checker record to the existing list and completes the write-through.
No scientific output, source snapshot or scoring rule changed.
