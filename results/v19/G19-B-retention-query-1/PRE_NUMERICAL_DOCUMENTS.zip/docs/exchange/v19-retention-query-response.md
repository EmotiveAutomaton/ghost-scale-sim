# V19 query-context retention

We tested whether averaging across future query contexts hides different retention errors. All 1,064 deterministic outputs match both complete replays; independent numerical reconstruction and paired regroup remain pending. This is a supplied-law constructed-method test, with no established learned provenance, historical process correspondence or human intent.

V19 remains active with 86 independently accepted scientific batches. Query-context retention execution and both complete replays are verified. Its independent checker passed 128 isolated controls and was observed executing through the existing serial queue. Highest-probability source retention and retention with a query announced before compression remain prepared alternatives. Earlier timing blockers and A3/C2/F2 prerequisites are unchanged.

[Report](../versions/v19-local-maker/RETENTION_QUERY_REPORT.md).
