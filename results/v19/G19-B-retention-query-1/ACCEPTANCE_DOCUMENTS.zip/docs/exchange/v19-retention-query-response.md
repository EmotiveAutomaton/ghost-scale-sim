# V19 query-context retention

We tested whether averaging across future query contexts hides different retention errors. At half copying, spaced half-retention lowers expected squared prediction loss by 0.00000009757 for presentation requests but raises it by 0.00000002654 for meaning requests in one source-aware setting. Independent reconstruction, all 1,120 paired strata and both complete replays verify this small descriptive reversal. This is a supplied-law constructed-method result; practical importance, learned provenance, historical process correspondence and human intent remain unestablished.

V19 remains active with 87 independently accepted scientific batches. Query-context retention has complete independent reconstruction and original-row regroup. Highest-probability source retention and retention with a query announced before compression remain prepared alternatives. Earlier timing blockers and A3/C2/F2 prerequisites are unchanged.

[Report](../versions/v19-local-maker/RETENTION_QUERY_REPORT.md).
