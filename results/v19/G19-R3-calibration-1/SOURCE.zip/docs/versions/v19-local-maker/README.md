# V19: local maker reconstruction and usable predictive state

Both tiny sequence readers pass the frozen predictive-capability thresholds in every fit and evidence condition. Independent model and score reconstruction and both complete replays verify the result. Fresh-episode prediction does not establish historical process reconstruction or selective causal access; the latter still needs intervention fixtures.

Persistent count-table learning improves native production, but active acquisition has no demonstrated advantage over demonstrations. Exact ordered replay is identical. Restricting starts leaves the unvisited context at its prior and lowers average success; this is a constructed-method comparison, not intent reconstruction or human expertise.

A fixed public-history reset reduces the rolled-in updater’s large error at 128 observations but does not rescue it: it still loses 3.47050 nats to the reset one-step head. One-step reset effects are small and change sign across source conditions. Independent forecasts, scores and both complete replays verify this bounded constructed-method result; numerical horizon extrapolation remains a rival to accumulated drift.

The single roll-in pass fails to stabilize the updater: independent 32-observation forecast loss increases by 5.74016 nats, with unchanged teacher-refit controls and complete reproducibility. The task study finds no skill-by-objective reversal; a complementary-path symmetry fixes display-on success at 50%, while hiding final evidence loses a small amount of purpose information. These are constructed-method and conditional model results, not human intent or learned expertise.

The [bounded optimizer comparison](CONVERGENCE_REPORT.md) and [recursive update](UPDATE_REPORT.md) are independently verified. The [prepared alternatives](NEXT_ALTERNATIVES_2026-09-21.md) distinguish
concrete future designs from implemented and admitted jobs.

The bounded optimizer comparison verifies an old-world relative bank advantage, local context benefit and strong witnessed-history reversal; none of its fits meets the declared gradient tolerance. The recursive updater preserves useful future predictions, but its modest history advantage reverses at the shorter prefix and its free/teacher gap includes initialization and oracle input privilege. Copied teacher positions are exact pass-throughs. Both results concern constructed methods, not joint historical correspondence or human intent.

This separately commissioned week begins from reviewed commit `110e03e`.
The [coding package](CODING_PACKAGE.md), immutable [acceptance](ACCEPTANCE.json)
and [opening manifest](OPENING_MANIFEST.json) control it. V18.4 remains closed.

The specifications are adequate to start implementation. The opening audit,
evidence packets and exact local world do not depend on a neural model winning.
The registry names later work without claiming that its handlers are implemented
or admitted. Every executable job needs its own frozen sources, inputs and checks.

## Review and implementation decisions made before new outcomes

- Accept 96 CPU hours over 168 elapsed hours, including validation and failures.
  Protect 16 CPU hours for confirmation, replay and closeout. The optional 120-hour
  ceiling is not accepted. Caps are ceilings, not occupancy promises.
- Freeze nested budgets 32/128/512/2048 and a 0.02-nat practical margin.
  Normalize trapezoid area by the log-budget span, so its units remain nats.
  Report each budget and each informative class as well as the area.
- Reserve separate development, test and confirmation lineages before fits.
  Training draws and initialization variability remain separate from conditional
  test-lineage uncertainty. Old retained coefficient draws are paired by index.
- Old program histories and supplied policy matrices are privileged inputs.
  Artifact-only packets omit program, hidden state, rule and controller labels.
  Packet hashes identify visible content; evaluator truth is a separate export.
- Floating-point rank is explicitly numerical. A truncated inverse residual is
  never a mathematical nonidentification certificate. Analytic null fixtures
  exercise that distinction before retained-data analysis.
- Use the resident environments without synchronization, one scientific worker,
  one numerical thread, CPU only and native below-normal priority. Tiny training
  waits for a shared ownership receipt; the two-setting allowance is combined
  across Ghost and Sounding Line.
- Later learned handlers must freeze their architecture, capacity matching,
  permitted features, target labels and optimization schedule before their fits.
  The initial registry does not silently decide those unresolved engineering details.

Portable scientific records belong under `results/v19/`; no machine-local operating material
belongs in a scientific export. The deadline includes setup time and never resets.

The [exact process-sufficiency review](PROCESS_SUFFICIENCY_REPORT.md) proves a reachable order alias for posterior-only fresh-episode banks. The optimizer and recursive-update comparisons are verified; none of these results closes the primary learning comparison or the week.

The [roll-in and task protocol](ROLL_IN_AND_TASK_PROTOCOL.md) freezes two independent successors. Implemented handlers still require source-bound admission before execution.

The [roll-in result](ROLL_IN_REPORT.md) and [task result](TASK_REPORT.md) are fully reviewed. The [fixed reset and longer-horizon protocol](BOUNDED_RESET_PROTOCOL.md) names the next intervention and two independent prepared alternatives.

The [bounded reset result](BOUNDED_RESET_REPORT.md) is fully reviewed. The [persistent practice protocol](PRACTICE_PROTOCOL.md) freezes its independent next comparison and retains two prepared alternatives.

The [persistent practice result](PRACTICE_REPORT.md) is fully reviewed, including the exact replay identity and context-support limitation.

The [tiny-reader capability pilot](TINY_READER_PROTOCOL.md) freezes the two shared
architecture settings before fitting. Independent portfolio and calibration
designs remain prepared; predictive capability alone cannot admit causal access.

The [tiny-reader capability result](TINY_READER_REPORT.md) is independently verified. Both settings pass; causal fixtures and the broader primary comparison remain open.
