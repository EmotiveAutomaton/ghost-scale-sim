# V19 cue-channel response - 25 September 2026

We tested whether misjudging cue reliability can harm storage when the source mixture is correct. When an uninformative cue is treated as two-thirds correct, cue-guided storage performs worse than ignoring it in 147 of 420 distinct problems. Independent rational reconstruction and both full replays verify this constructed-method reversal; it does not establish forecast accuracy or process correspondence.

V19 remains active with 106 independently accepted scientific batches. Cue-channel misspecification is independently verified. Robust channel regret and precision-choice stability remain prepared alternatives; neither is yet admitted. The immutable interim population remains 92; fourteen later acceptances are dated separately. Protected lineages, the 16-hour reserve and final time are unchanged.

[Report](../versions/v19-local-maker/CHANNEL_MISSPECIFICATION_REPORT.md).
