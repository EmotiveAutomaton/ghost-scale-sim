# Noisy mechanically supplied metadata: prepared independent alternative

Does one-field disclosure retain predictive value when its reply can be wrong?
The truthful disclosure experiment assumes reliable replies. Use the same 640
queries, eight existing laws and both tools; enumerate both binary replies with
known symmetric channel reliability 0.5, 0.75 and 1. No new sampling or fitting.

Compare no request, always skill, always belief and supplied-law entropy choice.
Select fields from visible-group expected endpoint entropy integrating over the
reply channel. Condition on noisy replies using that same declared channel.
Separately score a reader that incorrectly treats replies as certainly true;
preserve infinite-loss mass without clipping. Cross native versus equal-query
weights and costs 0, 0.02 and 0.1 nats per field. Report expected proper scores,
request rates and residual ambiguity; an averaged forecast is not an expected
score for a realized reply. Resolve exact field ties in favor of skill and
retain a numerical tie sensitivity audit.

Require the 0.5 reliability no-information identity, the reliability-one parent
reconstruction, known scalar Bayes updates, zero-mass fallback, normalization,
target-selection independence and deliberate corrupted reply-law controls.
Freeze all laws, reply probabilities, query memberships and source before
execution; independently reconstruct and replay before acceptance. The complete
enumeration has a 0.5 CPU-hour cap including controls and review within the
existing F/global allowance. Prepared, unimplemented; no outcomes admitted.

This tests a constructed noisy-information method, not the reliability of human
self-report, learned law access, or historical human intention. It remains
independent of retrospective quotient updating and adds no tiny setting or
protected confirmation lineage.
