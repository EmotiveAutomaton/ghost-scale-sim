# Unspecified reliability and a robust reply decision: prepared alternative

Can a reader make a finite-loss endpoint forecast without pretending to know
which of three supplied reply channels applies? This is an unimplemented,
unadmitted D-family decision alternative, independent of retrospective updating
and any advantage in the finite-set comparison.

Use the same 640 retained mechanical queries, eight development laws, two tool
rules, native and uniform legal-completion laws, and both scoring populations.
For each field and reply, rebuild candidate conditionals at accuracy 0.5, 0.75
and 1. Exclude zero-modeled-mass candidates. Compare the no-request forecast,
equal mixture of compatible candidate forecasts, and their normalized
coordinatewise maximum. The latter is a declared conservative coding rule,
not a posterior or a selected true reliability. All rules are fixed before
outcomes; there is no fitted parameter or architecture search.

Retain exact distributions, normalization constants, every branch logarithmic
and squared score, zero-target mass, and costs 0/0.02/0.1 per reply. Evaluate each
actual channel separately. The maximum normalized envelope has pointwise
regret at most the log of its normalizer relative to every compatible
distribution wherever that distribution gives positive target probability;
check this finite coding bound exhaustively. Distinguish this bound from a
guarantee about the actual endpoint when its candidate is excluded by a wrong
native prior. Report worst-channel expected loss without claiming minimax
optimality. Candidate duplication is a deliberate control for mixture
sensitivity; equivalent forecasts must not affect the envelope rule.

Freeze sources and a half-hour inclusive D-family cap before dispatch. Controls
cover singleton/constant collapse, normalization, disjoint supports, the coding
bound, candidate duplication, impossible-reply exclusion and deliberate
omission. Require complete replays and independent scalar reconstruction.
Reader packets expose only artifacts, operations, requested field, reply and
the declared candidate set. Truth, actual channel, laws and scores stay evaluator
evidence. No new fit, sampled episode, protected lineage or budget extension.
This is a supplied-law prediction decision, not human testimony or process
correspondence. The protocol does not claim an implemented handler.
