# V19 precision-stability response - 25 September 2026

We tested whether small arithmetic differences can change storage-precision choices. The interval check guarantees an optimum in 22 of 24 problems, while certifying every previously tied choice in only 17. Even the largest bound on lost objective value is below 0.000000000000048 in accumulated log-range units. Independent reconstruction and both full replays verify this constructed-method result within the box between two arithmetic evaluations; exact real-valued accuracy and process correspondence remain unestablished.

V19 remains active with 108 independently accepted scientific batches. Precision-choice stability is independently verified. Coupled arithmetic interpolation and realized-risk-constrained channel regret remain prepared alternatives; neither is yet admitted. The immutable interim population remains 92; sixteen later acceptances are dated separately. Protected lineages, the 16-hour reserve and final time are unchanged.

[Report](../versions/v19-local-maker/PRECISION_STABILITY_REPORT.md).
