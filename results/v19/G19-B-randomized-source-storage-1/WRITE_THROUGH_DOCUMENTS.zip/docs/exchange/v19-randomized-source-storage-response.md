# V19 randomized source storage response — 25 September 2026

We tested whether randomizing among byte-feasible storage choices improves protection against an uncertain source prior. Randomization increases minimum expected retained mass in 26 of 28 distinct problems, but every improving lottery has a worst realized mass below its deterministic baseline. Independent rational reconstruction, all 57,344 rows and both complete replays verify this constructed-method result. Forecast accuracy, learned provenance, historical process correspondence and human intent remain unestablished.

V19 remains active with 99 independently accepted scientific batches. Randomized source storage is independently verified. Precision-choice stability and randomized source-prior regret remain prepared alternatives. The immutable interim population remains 92; seven later acceptances are dated separately. Protected lineages, the 16-hour reserve and final time are unchanged.

[Report](../versions/v19-local-maker/RANDOMIZED_SOURCE_STORAGE_REPORT.md).
