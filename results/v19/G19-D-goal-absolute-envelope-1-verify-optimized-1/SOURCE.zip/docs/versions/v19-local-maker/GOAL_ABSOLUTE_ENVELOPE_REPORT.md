# Absolute residual envelope: execution and replay verified

We tested whether averaging within fixed probability bins hides frame-level absolute errors. All 1,296 deterministic outputs match the original and both complete replays. The independent checker passes 77 controls but exceeds this card’s admission budget after measured costs and reserves. This constructed-method diagnostic has verified replay; numerical acceptance, historical goal correspondence and human intent remain unestablished.

For each frame, subtract its native local-goal probability from the frozen
forecast, take the absolute value and weight it by its declared population mass.
Compare that unbinned error with the accepted five-, ten- and twenty-bin absolute
discrepancies. Triangle inequalities make the gaps nonnegative, and nested
refinement makes them nonincreasing, up to the frozen -1e-12 roundoff tolerance.
Negative roundoff remains visible. This bounds aggregation error; it does not
improve any reader forecast or select a better partition.

All sixteen development laws, two training draws, five fit seeds, four label
budgets, four readouts, two forecasts, three positions and three goals remain.
Native and equal-frame populations are separate. There are 92,160 score rows,
320 group bundles, 320 forecast bundles, 320 raw residual bundles, 225,280 frame
forecasts, 704 reader packets and 5,120 parent score identities. No new fit,
sample, model setting or protected lineage is used.

All 1,296 deterministic files match original, adjacent and extracted-source
runs. The 740 sources, 331
inputs, plans, source archives, environments, outputs and timing bindings verify.
This establishes execution and replay acceptance. Independent numerical
acceptance remains pending; the accepted scientific count remains 71.

The new checker uses accurate scalar absolute-residual sums and signed-bin
sums, independently rebuilding every saved residual and weighted contribution.
It rebuilds bin weights, forecast and target sums, empty means and native self;
checks all accepted bin discrepancies, full parent rosters, fine forecast loss
and modal goal accuracy; and compares every saved forecast and schema. Scalar
base-three sums check the native matrix projection while preserving the executed
binary64 bin boundaries. This is not an independent numerical-library audit.

The checker will regroup original and reconstructed rows separately.
Required outputs are 576 means, 1,728 within-readout envelope estimates, 3,024
baseline budget contrasts and 756 normalized log-budget areas. Seed 191021 fixes
10,000 paired sixteen-law resamples, retaining both draws and all five fit seeds
inside each law. Draw and seed variation stay separate. A third direct-index
regroup remains required for final numerical acceptance. Intervals condition on
retained fits; no practical-impact threshold or architecture winner is specified.

All 77 isolated controls passed in 192.61 seconds, with no skips or warnings.
They cover constant and opposing residuals, unequal and zero weights, native
self, permutations, exact and adjacent bin boundaries, probability one, empty
means, complete synthetic execution, missing and duplicate rosters, deliberately
corrupted raw arrays, forecasts, parent bin scores, summaries and schemas, plus
native and portable dispatch. The first suite passed 76 controls and failed one
no-op corruption fixture: reversing a singleton frame list. The corrected test
alters its identifier explicitly. Checker and producer scoring are unchanged;
the failed log and its resource cost are retained.

Numerical execution is blocked by the inclusive 1,800 CPU-second card. A refined
synthetic benchmark measured complete sixteen-law reconstruction, compressed
array I/O, parent scores, all 92,160-row paired estimates and archive roundtrips.
Using the slower of two full-size bundles, a 50% margin, four regroup passes,
four archive passes and 90 additional I/O/documentary seconds requires 970.219
further CPU seconds. Prior use, the benchmark itself and 120 operating seconds
bring the conservative total to 1,822.049 seconds. The earlier estimate left
less than one second before its own charge and did not support admission either.
No safety margin was reduced and no card or family ceiling was extended.

The tested source snapshot is retained separately. It is prepared, not admitted;
no checker job or second scientific owner was launched. This scope-specific
blocker does not close V19 or imply scientific exhaustion. Independent alternatives
remain prepared. A future cost reduction must name its cause, preserve controls
and fit the unchanged inclusive cap, including all retained failed work.

Reader packets are archived separately from inherited scientific inputs, native
targets, forecasts, raw residual arrays and scores. This is an
exploratory constructed-method diagnostic, miniature — architecture untested
beyond the declared roster. Historical goal correspondence and human intent
remain unestablished. Retrospective evidence updating and exact forecast-collision
uncertainty remain independent prepared alternatives requiring implementation,
tractability checks and source admission.

[Execution contract](GOAL_ABSOLUTE_ENVELOPE_ADMISSION_PROTOCOL.md).
[Independent checker](GOAL_ABSOLUTE_ENVELOPE_REVIEW_PROTOCOL.md).
[Execution evidence](../../../results/v19/G19-D-goal-absolute-envelope-1/EXECUTION_REVIEW.json).
[Evidence roles](../../../results/v19/G19-D-goal-absolute-envelope-1/EXECUTION_EVIDENCE_ROLES.json).
