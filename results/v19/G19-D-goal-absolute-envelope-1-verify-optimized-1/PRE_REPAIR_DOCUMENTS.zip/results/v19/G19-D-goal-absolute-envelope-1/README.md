# Absolute residual envelope: execution and replay verified

We tested whether averaging within fixed probability bins hides frame-level absolute errors. All 1,296 deterministic outputs match the original and both complete replays. The independent checker passes 77 controls but exceeds this card’s admission budget after measured costs and reserves. This constructed-method diagnostic has verified replay; numerical acceptance, historical goal correspondence and human intent remain unestablished.

Reader, inherited scientific inputs and scientific outputs have separate archives.
