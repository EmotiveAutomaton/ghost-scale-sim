# One-field metadata disclosure: prepared independent alternative

Can a bounded request for one missing mechanic field reduce endpoint uncertainty
without receiving the endpoint itself? Starting from both skill and belief hidden,
reuse all 640 retained queries, eight development laws and both tools. Add no new
episode, operator, fitted reader, architecture, seed or protected lineage.

Compare no disclosure, always skill, always belief, and a supplied-law policy
choosing the field with the largest expected reduction in endpoint entropy from
the visible query. Resolve exact ties in favor of skill. Include an equal mixture
of the two requests with its exact expected proper score, not a sampled coin.
Each request reveals the actual binary field; it never reveals the endpoint.
The all-fields oracle is a separately labelled ceiling. Decision policies use
visible query groups and supplied conditional laws, never the individual query's
hidden field or realized target when selecting a request.

Freeze all memberships, queries, tie rules and probabilities before execution.
Report raw native-population and equal-query scores, residual ambiguity, request
rates and net loss at costs 0, 0.02 and 0.1 nats per disclosed field. The uniform
legal-completion and exact native-law weighting cases remain separate; preserve
zero-mass groups and infinite-loss mass. Check identical visible inputs receive
identical choices, a field-independent null, a known informative field, all-fields
identity, probability mass and deliberate target-leak corruption. A full replay
and independent reconstruction are required before acceptance.

This is an oracle value-of-information method comparison under mechanically
available disclosure. It establishes neither that a human's belief can be queried
reliably nor that a reader learned the law or recovered historical intention.
Cap one CPU hour including controls, replay and review within the unchanged
F/global ceilings. No handler or outcome is admitted. It remains independent of
pooled feedback replacement and retrospective future-schedule updating.
