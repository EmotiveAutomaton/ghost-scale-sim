# Independent unknown-source retrospective review

Freeze this checker before executing it against the native outputs. It imports
no source-identity producer kernels. Independently decoded bit schedules and
indexed state-change accumulations replace the producer's sparse operator.
Scalar sums over sixteen states rebuild every source/report normalizer; each
source's complete hypothesis numerator is accumulated separately. Check exact
source Bayes weights, compatible-source uniform averaging coefficients, entropy,
all support masks, both rivals' future-schedule total variation and every future
time/context/endpoint discrepancy. Unsupported errors must be NaN, never zero.
All comparisons use the existing absolute tolerance 1e-12, with exact identity
and support-mask checks. No tolerance or roster change follows native outcomes.

Check all 28,672 original posteriors, 505,856 source candidates, five copy
probabilities and eight endpoints. The 48 absent checkpoint strata stay absent.
Source uncertainty stays inside each posterior; report errors are weighted by
the exact marginalized report law. Rebuild every summary row and 1,120 paired
law/evidence/checkpoint/draw/copy-probability strata, preserving 128 rows per draw.
A separate event-owned regroup of original summaries must verify both draws
inside eight equally weighted laws before numerical acceptance.

Synthetic controls include direct full-hypothesis Bayes at every future
coordinate, constant/sparse/disjoint laws, unequal likelihoods, one source,
permutation, malformed inputs, altered raw values, NaN support changes and full
producer/checker integration. Test in an isolated source copy. Time complete
synthetic archives with every native structural shape, including decompression;
include reconstruction, regroup and publication in the existing 3,600 CPU-second
card and B/global limits before admission. Preserve failures and sources.

Inputs bind the accepted parent laws, posteriors and true source identities.
This is a supplied-law constructed-method diagnostic, not learned provenance or
historical process correspondence. All new exports are scientific/evaluator
evidence. Two-report dependence and source-identity disclosure remain prepared
alternatives; this checker consumes no model setting or protected lineage.
