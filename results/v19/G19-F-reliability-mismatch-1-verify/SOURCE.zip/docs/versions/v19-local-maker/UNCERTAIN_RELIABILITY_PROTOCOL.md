# Unknown reply reliability: prepared finite hypothesis-set alternative

Can a reader state which endpoint forecasts remain compatible with a reply when
the reply's reliability is unspecified? This is a D-family missing-hypothesis
alternative, independent of retrospective updating and mismatch rankings. It is
prepared, unimplemented and unadmitted; a protocol is not an executable handler.

Use the retained 640 queries, eight development laws, both tool rules, both
conditional laws and native/equal-query populations. Skill and belief are requested
once separately. Reliability is one of exactly 0.5, 0.75 or 1, with no privileged
prior or selected winner. Enumerate each legal reply under each candidate channel.
The reader receives artifacts, operations, requested field, reply bit and the
three-element reliability set. It never receives actual accuracy or hidden truth.

Retain the complete set of three endpoint distributions and their coordinatewise
envelope. Test containment of every candidate conditional and construct complete
pairwise disagreements; enumerate all groups, not a selected witness. Distinguish
an envelope from a normalized joint forecast: independently choosing endpoint
extremes may not yield a coherent distribution. Report the diameter in total
variation (half the sum of absolute probability differences), endpoint range
widths and sets that collapse to one forecast. Supply no point forecast or
calibration guarantee without a declared reliability prior. A candidate with
zero modeled reply mass is impossible under that candidate; its conventional
fallback must be separately flagged and excluded from compatibility claims.
Actual-channel zero probability is evaluator-only and does not delete a possible
reader packet. This is finite-set uncertainty, not a continuum certificate.

Controls precede execution: constant endpoint collapse, half-channel prior
identity, truthful scalar conditioning, all-candidate containment, coherent
versus coordinatewise composition, zero-support exclusion, full group/field/reply
coverage and deliberate omitted-candidate corruption. Freeze implementation,
inputs and source; require both complete replays, independent scalar rebuilding
and paired law summaries before acceptance. Preserve full reader/evaluator roles.

The half-hour CPU ceiling includes controls, original, replays, review and
failures within the existing D and global budgets. Check tractability and budget
before admission. No fitting, episode sampling, protected lineage, source mutation
or new owner is authorized. Complete set recovery is an apparatus guarantee;
it does not establish a learned reader, human testimony or process correspondence.
