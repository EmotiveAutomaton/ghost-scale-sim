# V19 fixed-byte retention

We tested whether equal memory budgets change which past sources can be retained. At the final 32-observation checkpoint, midpoint priority retains five fewer sources on average than recency under each shared budget, and predicts less accurately when copying has probability one half. Independent reconstruction, all 1,120 paired strata and both complete replays verify this supplied-law constructed-method result. Practical importance, learned provenance, historical process correspondence and human intent remain unestablished.

V19 remains active with 88 independently accepted scientific batches. Fixed-byte retention has complete independent reconstruction and original-row regroup. Highest-probability source retention and aggregate single-report state remain prepared alternatives; query-announced retention remains timing-blocked after one identified repair. Earlier timing blockers and A3/C2/F2 prerequisites are unchanged.

[Report](../versions/v19-local-maker/BYTE_RETENTION_REPORT.md).
