# V19 aggregate single-report state

We tested whether one fixed report law can be retained without separate tables for every past source. All supported updates and future forecasts reconstruct within rounding error. Aggregate storage beats per-source tables at six of seven checkpoints, but beats full hypothesis weights only at the final 32-observation checkpoint: 1,184 versus 4,480 bytes, excluding separately counted law and schedules. Independent reconstruction, all 1,120 paired strata and both complete replays verify this supplied-law constructed method. Learned access, historical process correspondence and human intent remain unestablished.

V19 remains active with 89 independently accepted scientific batches. Single-report aggregate state is independently verified. The context-disclosure aggregate prototype passed 30 controls but remains timing-blocked after one algebraic repair; no native science was dispatched. Highest-probability retention and a fixed bank of source-prior tables remain prepared alternatives. Earlier timing blockers and A3/C2/F2 prerequisites are unchanged.

[Report](../versions/v19-local-maker/AGGREGATE_REPORT_STATE_REPORT.md).
