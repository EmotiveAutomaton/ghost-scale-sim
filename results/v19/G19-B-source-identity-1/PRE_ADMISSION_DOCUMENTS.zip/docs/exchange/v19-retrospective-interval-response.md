# V19 retrospective provenance intervals

We tested whether uncertainty about copying leaves bounded future forecasts after a report about the past. With copying probability anywhere from zero to one, the mean of each source’s largest future-probability width is 0.00492–0.01370 across retained settings. Independent reconstruction, all 896 paired strata and both complete replays verify this supplied-law constructed-method result. Learned provenance, historical process correspondence and human intent remain unestablished.

V19 remains active with 78 independently accepted scientific batches. Provenance-interval bounds and all 896 paired strata are independently verified. Two-report dependence and unknown source identity remain prepared, unimplemented alternatives. The prior-conditional reachable rival remains timing-blocked.

[Report](../versions/v19-local-maker/RETROSPECTIVE_INTERVAL_REPORT.md).
