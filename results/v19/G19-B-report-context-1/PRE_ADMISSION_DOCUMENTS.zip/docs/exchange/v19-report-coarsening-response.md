# V19 report-content misspecification

We tested whether binary reports preserve the future information carried by full endpoint reports. With a half chance of copying, each fixed binary report loses over 99.3% of the full report's small future squared-loss improvement (0.0000099–0.000164). Independent reconstruction, all 1,120 paired strata and both complete replays verify this supplied-law constructed-method result. Learned provenance, historical process correspondence and human intent remain unestablished.

V19 remains active with 81 independently accepted scientific batches. Fixed report-content coarsening has complete independent numerical reconstruction and paired regroup. Two-report dependence and report-context disclosure remain prepared alternatives; source disclosure and the prior-conditional reachable rival remain timing-blocked.

[Report](../versions/v19-local-maker/REPORT_COARSENING_REPORT.md).
