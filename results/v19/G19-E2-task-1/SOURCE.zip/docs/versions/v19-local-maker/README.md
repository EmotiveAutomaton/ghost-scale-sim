# V19: local maker reconstruction and usable predictive state

The [bounded optimizer comparison](CONVERGENCE_REPORT.md) and [recursive update](UPDATE_REPORT.md) are independently verified. The [prepared alternatives](NEXT_ALTERNATIVES_2026-09-21.md) distinguish
concrete future designs from implemented and admitted jobs.

The bounded optimizer comparison verifies an old-world relative bank advantage, local context benefit and strong witnessed-history reversal; none of its fits meets the declared gradient tolerance. The recursive updater preserves useful future predictions, but its modest history advantage reverses at the shorter prefix and its free/teacher gap includes initialization and oracle input privilege. Copied teacher positions are exact pass-throughs. Both results concern constructed methods, not joint historical correspondence or human intent.

This separately commissioned week begins from reviewed commit `110e03e`.
The [coding package](CODING_PACKAGE.md), immutable [acceptance](ACCEPTANCE.json)
and [opening manifest](OPENING_MANIFEST.json) control it. V18.4 remains closed.

The specifications are adequate to start implementation. The opening audit,
evidence packets and exact local world do not depend on a neural model winning.
The registry names later work without claiming that its handlers are implemented
or admitted. Every executable job needs its own frozen sources, inputs and checks.

## Review and implementation decisions made before new outcomes

- Accept 96 CPU hours over 168 elapsed hours, including validation and failures.
  Protect 16 CPU hours for confirmation, replay and closeout. The optional 120-hour
  ceiling is not accepted. Caps are ceilings, not occupancy promises.
- Freeze nested budgets 32/128/512/2048 and a 0.02-nat practical margin.
  Normalize trapezoid area by the log-budget span, so its units remain nats.
  Report each budget and each informative class as well as the area.
- Reserve separate development, test and confirmation lineages before fits.
  Training draws and initialization variability remain separate from conditional
  test-lineage uncertainty. Old retained coefficient draws are paired by index.
- Old program histories and supplied policy matrices are privileged inputs.
  Artifact-only packets omit program, hidden state, rule and controller labels.
  Packet hashes identify visible content; evaluator truth is a separate export.
- Floating-point rank is explicitly numerical. A truncated inverse residual is
  never a mathematical nonidentification certificate. Analytic null fixtures
  exercise that distinction before retained-data analysis.
- Use the resident environments without synchronization, one scientific worker,
  one numerical thread, CPU only and native below-normal priority. Tiny training
  waits for a shared ownership receipt; the two-setting allowance is combined
  across Ghost and Sounding Line.
- Later learned handlers must freeze their architecture, capacity matching,
  permitted features, target labels and optimization schedule before their fits.
  The initial registry does not silently decide those unresolved engineering details.

Portable scientific records belong under `results/v19/`; no machine-local operating material
belongs in a scientific export. The deadline includes setup time and never resets.

The [exact process-sufficiency review](PROCESS_SUFFICIENCY_REPORT.md) proves a reachable order alias for posterior-only fresh-episode banks. The optimizer and recursive-update comparisons are verified; none of these results closes the primary learning comparison or the week.

The [roll-in and task protocol](ROLL_IN_AND_TASK_PROTOCOL.md) freezes two independent successors. Implemented handlers still require source-bound admission before execution.
