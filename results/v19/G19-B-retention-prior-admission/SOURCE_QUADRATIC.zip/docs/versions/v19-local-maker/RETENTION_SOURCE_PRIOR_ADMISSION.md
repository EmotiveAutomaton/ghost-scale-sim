# Fixed retention under nonuniform source priors: execution contract

Does retaining recent or evenly spaced source times preserve retrospective value
when reports favor earlier or later sources? Implement the prepared source-prior
sensitivity protocol without choosing settings from outcomes. Use uniform mass,
mass proportional to original source time, and mass proportional to reciprocal
time, each normalized over every distinct candidate source.

Keep the complete 28,672 posteriors and 505,856 source candidates, eight development
laws, both evidence conditions, two draws and seven available checkpoint/horizon
cells. The 48 unavailable strata stay absent. Each draw retains 128 Cartesian
identities. Evaluate five copy probabilities, every endpoint and future coordinate.
All three source priors cross full retention and recent/spaced half/quarter counts.
Spacing uses the existing sorted-time midpoint rule. No source sampling or fitting.

Selected sources retain their original weighted joint contribution. Omitted
sources retain their original probability times the original uniform sixteen-maker
prior likelihood; no renormalization onto selected sources is permitted. Copied
endpoints use the complete weighted histogram. Full retention under each same
true prior is the reference; this is retention, not prior misspecification.

Store all source probabilities, selection masks, weighted remainder by context,
copy histogram, normalization constant, report probabilities, support/undefined
masks, proper squared regret, maximum future error, group total variation and
storage counts. Thirteen float64 values hold eight copied-endpoint masses, four
remainder-context masses and a normalization constant. Retained source weights
are recoverable from stored times and the supplied prior rule. Mixed joint cells
and group weights add float64 storage; source identities and structural indices
use int32. The shared prior table has 32 floats. Full-hypothesis weight storage
is reported separately; these counts are not optimized query latency.

Before dispatch require direct scalar group/report Bayes and explicit expected
one-hot losses, materialized joint tables, weighted remainder normalization,
source permutation with identities fixed, constant/full/copy identities, uniform
reduction to the accepted unweighted experiment and deliberate remainder faults.
Require synthetic timing for all seven structures and both source densities,
including every prior, state, copy probability, future coordinate and serialization.
Freeze architecture, teacher labels, schedule, inputs, source and environment.

The existing single-worker queue owns original, adjacent and extracted-source
executions. The prospective inclusive cap is 3,600 CPU seconds for all preparation,
failures, three executions, independent reconstruction and original-row regroup.
Preserve family/global ceilings and confirmation reserve. Timing failure cannot
authorize sampling, changed scores or extra CPU. Numerical acceptance requires
independent weighted Bayes reconstruction and separate regroup of original rows:
two draws inside eight equally weighted laws, all priors and count contrasts paired.
No practical margin or confirmatory interval is frozen.

This is a supplied-law constructed-method comparison. No learned provenance,
historical process correspondence or human intent follows. Two-report dependence
and retained-source-probability selection remain prepared, unimplemented alternatives.
