# V19 absolute residual envelope

We tested whether averaging within probability bins hides frame-level absolute errors. At 2,048 labels, even twenty bins conceal 7.7–13.3% of the predictive bank’s absolute probability error across positions under native weighting. Independent reconstruction, all 5,508 paired estimates and both complete replays verify this constructed-method diagnostic. Historical goal correspondence and human intent remain unestablished.

[Report](../versions/v19-local-maker/GOAL_ABSOLUTE_ENVELOPE_REPORT.md).
