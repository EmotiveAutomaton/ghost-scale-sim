# V19 absolute residual envelope

We tested whether averaging within fixed probability bins hides frame-level absolute errors. All 1,296 deterministic outputs match the original and both complete replays. The optimized independent checker passes 81 controls and completes within the unchanged inclusive card budget. Final independent regrouping and scientific acceptance remain pending. This is a constructed-method diagnostic; historical goal correspondence and human intent remain unestablished.

[Report](../versions/v19-local-maker/GOAL_ABSOLUTE_ENVELOPE_REPORT.md).
