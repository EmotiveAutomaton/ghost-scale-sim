# V17 bounded scientific replay (evaluator material)

This archive contains private constructed truth and must not be supplied as blind
reader evidence. The database is deliberately a 102-unit subset, not the full
continuation database. It reproduces the first/last committed units in all 51
phase/branch surfaces: 792 cases and 11,480 rows. It cannot reconstruct full-run
aggregate statistics. ORIGINAL_REPLAY.json identifies the selection and hashes.

Extract to a new directory. Use Python 3.13 and the exact admitted native Stitch
executable plus libunwind.dll (external hashes are in PLAN.json; binaries are not
included). From source/, run with an explicit interpreter and absolute paths:

python -B -m runners.replay_v17_continuation --run-root <extracted-root> --out <new-output-directory> --stitch <compress.exe>

The command checks all frozen source/external hashes, retrains the development
controller, regenerates each full unit with fresh learner caches and compares
bytes, then executes the original extracted reader and private-read probe.
The original reader ZIP retains stale pilot wording; its scientific inputs are
unchanged. Use the separately delivered reader-final.zip for the final challenge.
This is deterministic bounded replay, not independent generative implementation,
architecture validation, human evidence or a complete public raw-data release.
