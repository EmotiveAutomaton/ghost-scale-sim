# V17 final illustrative observer challenge
Predict a constructed maker's unseen next choice after the declared intervention.
Each JSON line contains an opaque task ID, finite answer support, query cost,
permitted evidence tier, and a known finite family of possible native makers.
The actual maker policy and goal are withheld. These are new constructed cases,
not human tasks or a claim that historical reconstruction is unique.

A uses place/remove actions 0..15/16..31 on a sixteen-cell board.
B uses the same display physics, a finite Bayesian recipient, and STOP.
C renders a decoder's most likely interpretation as an executed display; the
future choice is the decoder's next interpretation after more observations.
D uses assembly attach 0..2, remove 3..5, rotate 6..8 and STOP 9. Supporting
parts cannot be rotated or removed while dependents remain attached.

An artifact is a bit mask: bit k says cell k is present. Assembly displays encode
part k with orientation v as bit 2*k+v. The context declares earlier and future
opportunities, possible goal settings and interventions; it does not identify
which hypothesis actually produced the observations. Earlier objects and process
evidence appear only in their stated tiers. No dates are supplied.

Run: python -B consumer.py < requests.jsonl > predictions.jsonl
The standard-library reference enumerates the declared maker family. Alternative
methods are surface_continuation and episodic_continuation. It reports all
probabilities, modeled operation/storage costs and compatible histories.
It closes file/process/network access after trusted imports. This is a boundary
for this fixed Python consumer, not a sandbox for hostile native code.

The evaluator ZIP is separate. These six cases (eighteen evidence-tier requests)
were selected by lowest case hash within each observed outcome type and each
of the four native observer families in the completed expansion cohort.
Selection used outcomes: this is an illustrative challenge, not an unbiased
evaluation population or a fresh confirmation. Wrong-recipient, wasted-work
and surprising-edit examples are absent as blind reader types. Evaluator-only
illustrations cover those types. A plausible-history-wrong tag is a proxy:
multiple compatible histories plus a wrong future prediction, not an
independently scored reconstruction of a particular historical path.
The versioned adapter wraps old V16 payloads without changing their schema.
