# V17 initial A evaluator snapshot

Contains evaluator truth. Do not give this archive to a blind reader.
This is a limited A baseline slice, not a completed V17 study.

From this extracted directory, with Python 3.10 or newer:

    python -m runners.verify_v17_packet --root results/v17/a-screen-1

The original verification receipt includes a timestamp, so this command
refuses to overwrite it. To run the read-only check without writing a receipt:

    python -c "from runners.verify_v17_packet import verify; print(verify('results/v17/a-screen-1'))"

Re-run the construction fixture into a new directory:

    python -m runners.run_v17 --stage fixture --root fresh-fixture

Raw chunks, proper source hashes and original receipts are retained.
No third-party library or Rust toolchain is needed for this baseline snapshot.
