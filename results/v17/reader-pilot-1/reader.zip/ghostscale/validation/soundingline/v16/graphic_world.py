from collections import Counter
from itertools import product

def execute(program, *, initial=0, max_steps=6):
    if type(max_steps) is not int or max_steps < 0:
        raise ValueError('invalid execution limit')
    if type(initial) is not int or not 0 <= initial < 65536:
        raise ValueError('invalid sixteen-cell starting state')
    board = initial
    trace = []
    for index, action in enumerate(program):
        if index >= max_steps:
            return {'artifact': board, 'legal': False, 'stopped': False, 'error': 'timeout', 'primitive_cost': index, 'trace': trace}
        before = board
        legal = type(action) is int and 0 <= action < 32
        if legal:
            board = board | 1 << action if action < 16 else board & ~(1 << action - 16)
        trace.append({'before': before, 'action': action, 'after': board, 'legal': legal})
        if not legal:
            return {'artifact': board, 'legal': False, 'stopped': True, 'error': 'illegal primitive', 'primitive_cost': index + 1, 'trace': trace}
    return {'artifact': board, 'legal': True, 'stopped': True, 'error': None, 'primitive_cost': len(trace), 'trace': trace}

def learn(training):
    counts = Counter()
    processing = 0
    for trial in training:
        result = execute(trial['program'])
        processing += result['primitive_cost']
        if trial['feedback'] and result['legal'] and (result['artifact'] == trial['target']):
            counts[tuple(trial['program'])] += 1
    eligible = [p for p, count in counts.items() if len(p) == 2 and count >= 4]
    library = [list(min(eligible, key=lambda p: (-counts[p], p)))] if eligible else []
    return {'library': library, 'definition_cost': sum(map(len, library)), 'processing_primitives': processing}
