from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
from datetime import datetime, timezone

def canonical(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')

def digest(value: object) -> str:
    return hashlib.sha256(canonical(value)).hexdigest()

def seed_for(*parts: object) -> int:
    return int(digest(parts)[:16], 16)
