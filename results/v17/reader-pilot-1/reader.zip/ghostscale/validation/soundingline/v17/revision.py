import random
from ..v16 import assembly
from ..v16.records import digest, seed_for
from .contracts import Costs, forecast_scores
from . import recipient as b
METHODS = ('local_edit', 'dependency_aware', 'internal_reconsideration', 'recipient_feedback', 'complete_error_monitor', 'stop_always')

def encode(state):
    return sum((1 << 2 * k + value for k, value in enumerate(state) if value >= 0))

def recipient_world(targets):
    return dict(templates=[encode(target) for target in targets], visible=63)

def candidate_values(public, goal, costs, local=False):
    values = []
    world = recipient_world(public['goal_options'])
    model = dict(order=[0, 1], precision=1.2, prior=[0.5, 0.5])
    for candidate in public['candidates']:
        costs.charge('proposal_generation')
        costs.charge('hypothetical_execution', candidate['primitive_cost'])
        state = candidate['state']
        target = public['goal_options'][goal]
        if local:
            value = float(state[0] == target[0])
        else:
            response = b.recipient(encode(state), world, model, costs)
            physical = 1 - assembly.mismatch(state, target) / 3
            value = 0.5 * physical + 0.5 * response[goal]
        costs.charge('selection')
        values.append(value - public['edit_price'] * max(0, candidate['primitive_cost'] - 1))
    return values

def predict(public, method, *, feedback=None, supplied_goal=None):
    required = {'schema', 'world', 'initial', 'goal_options', 'remembered_goal', 'purpose_revision_announced', 'candidates', 'edit_price', 'feedback_budget', 'answer_support', 'query_contract'}
    if set(public) != required or public['schema'] != 'v17.revision.1':
        raise ValueError('revision public schema violation')
    if method not in METHODS:
        raise ValueError('unknown revision method')
    costs = Costs()
    world = assembly.World(tuple(public['world']['parents']), tuple(public['world']['defaults']))
    for candidate in public['candidates']:
        check = assembly.execute(world, candidate['program'], public['initial'])
        if not check['legal'] or not check['successfully_stopped'] or check['state'] != candidate['state']:
            raise ValueError('invalid offered assembly execution')
    goal = public['remembered_goal']
    if method == 'complete_error_monitor':
        if supplied_goal not in (0, 1):
            raise ValueError('complete monitor requires explicit true-goal assistance')
        goal = supplied_goal
    if method == 'stop_always':
        probabilities = [1.0] + [0.0] * (len(public['candidates']) - 1)
        values = None
        costs.charge('selection')
    else:
        values = candidate_values(public, goal, costs, method == 'local_edit')
        if method in ('internal_reconsideration', 'recipient_feedback'):
            before = sum(costs.values.values())
            alternative = candidate_values(public, 1 - goal, costs)
            pass_cost = sum(costs.values.values()) - before
            probe = max(range(len(values)), key=lambda k: abs(values[k] - alternative[k]))
            costs.charge('selection', len(values))
            if method == 'recipient_feedback':
                if feedback is None or public['feedback_budget'] < 1:
                    raise ValueError('feedback arm requires an available query')
                observation = feedback(probe)
                costs.charge('feedback_query', pass_cost)
                if observation is not None and abs(observation - alternative[probe]) < abs(observation - values[probe]):
                    values = alternative
            else:
                values = candidate_values(public, goal, costs)
        probabilities = b.softmax(values, 5)
    chosen = max(range(len(probabilities)), key=probabilities.__getitem__)
    result = assembly.execute(world, public['candidates'][chosen]['program'], public['initial'])
    costs.charge('actual_execution', result['primitive_cost'])
    return dict(probabilities=dict(zip(public['answer_support'], probabilities)), chosen=chosen, execution=result, costs=costs.receipt(16), values=values, represented_variables=['local_orientation'] if method == 'local_edit' else ['dependency_graph', 'remembered_goal', 'recipient_effect'])
