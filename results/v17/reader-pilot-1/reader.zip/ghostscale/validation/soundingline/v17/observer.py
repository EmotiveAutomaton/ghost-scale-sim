import copy
from itertools import product
import random
from ..v16 import assembly
from ..v16.records import digest, seed_for
from . import recipient as b, adaptive as c, revision as d, craft_extension as a
from .contracts import Costs, COST_KINDS, forecast_scores
from .programs import execute as graphic_execute
METHODS = ('surface_continuation', 'episodic_continuation', 'inverse_maker')
TIERS = ('artifact', 'artifact_collection', 'recorded_process')

def hypotheses(context):
    methods = {'A': ('primitive_search', 'repeated_fragments', 'episodic_adaptation'), 'B': ('physical', 'communicator', 'producer_editor'), 'C': ('cached', 'retrieval', 'inverse_3', 'inverse_full'), 'D': ('local_edit', 'dependency_aware')}
    return [dict(goal=goal, method=method) for goal, method in product(range(2), methods[context['family']])]

def forward(context, hypothesis, phase):
    """Execute one possible maker; called with public context and a hypothesis only."""
    task = copy.deepcopy(context['tasks'][phase])
    family = context['family']
    goal = hypothesis['goal']
    if family == 'A':
        cells = context['cells']
        task['target'] = sum((1 << x for x in (cells[:3] if goal == 0 else cells[1:4])))
        training = []
        for pair in (cells[:2], cells[1:3], cells[2:4]):
            for _ in range(4):
                training.append(dict(initial=0, program=pair, target=sum((1 << x for x in pair)), forbidden=[], feedback=True))
        task['training'] = training
        rep = a.acquire(task, hypothesis['method'], 32, {})
        result = a.solve(task, rep, 512)
        run = result['execution']
        artifact = run['state'] if run is not None else task['initial']
        choice = str(result['program'][0]) if result['program'] else 'MISSING'
        process = dict(actions=run['trace'] if run else [], missing=result['missing_output'])
        return dict(artifact=artifact, choice=choice, process=process, costs=result['costs'])
    if family == 'B':
        n = len(task['world']['templates'])
        desired = [float(k == goal) for k in range(n)]
        model = dict(order=list(range(n)) if phase < 3 else list(reversed(range(n))), precision=1.2, prior=[1 / n] * n)
        costs = Costs()
        opportunities = b.opportunities(task['artifact'], task['world'])
        probabilities = b.accepted_distribution(opportunities, task['world'], desired, [(model, 1)], hypothesis['method'], 'correct', costs)
        chosen = max(range(len(probabilities)), key=probabilities.__getitem__)
        candidate = opportunities[chosen]
        run = graphic_execute(candidate['program'], initial=task['artifact'])
        costs.charge('actual_execution', run['primitive_cost'])
        response = b.recipient(run['artifact'], task['world'], model, costs)
        return dict(artifact=run['artifact'], choice=candidate['id'], process=dict(actions=run['trace'], recipient_response=max(range(n), key=response.__getitem__)), costs=costs.receipt(16))
    if family == 'C':
        task['task']['shared_brief'] = [float(k == goal) for k in range(2)]
        result = c.option_prediction(task, hypothesis['method'])
        probabilities = result['recipient']
        choice = max(probabilities, key=probabilities.get)
        run = graphic_execute([context['cells'][int(choice)]])
        costs = Costs({k: result['costs'][k] for k in COST_KINDS})
        costs.charge('actual_execution', run['primitive_cost'])
        return dict(artifact=run['artifact'], choice=choice, process=dict(actions=run['trace'], represented_variables=result['represented_variables'], evaluated_hypotheses=result['hypotheses']), costs=costs.receipt(16))
    task['remembered_goal'] = goal
    result = d.predict(task, hypothesis['method'])
    program = task['candidates'][result['chosen']]['program']
    return dict(artifact=d.encode(result['execution']['state']), choice=str(program[0]), process=dict(actions=result['execution']['trace']), costs=result['costs'])

def predict(request, method):
    required = {'schema', 'target_kind', 'answer_support', 'query_cost', 'context', 'artifact', 'evidence_tier'}
    tier = request['evidence_tier']
    if tier != 'artifact':
        required.add('earlier_artifacts')
    if tier == 'recorded_process':
        required.add('recorded_process')
    if set(request) != required or request['schema'] != 'v17.observer.1':
        raise ValueError('observer explicit evidence schema violation')
    if method not in METHODS:
        raise ValueError('unknown observer method')
    support = request['answer_support']
    costs = Costs()
    forecasts = []
    weights = []
    compatible = []
    for hypothesis in hypotheses(request['context']):
        if method != 'inverse_maker' and hypothesis['method'] != hypotheses(request['context'])[0]['method']:
            continue
        current = forward(request['context'], hypothesis, 2)
        future = forward(request['context'], hypothesis, 3)
        for result in (current, future):
            for kind in COST_KINDS:
                costs.charge('hypothetical_execution' if kind in ('actual_execution', 'training_acquisition') else kind, result['costs'][kind])
        mismatch = (current['artifact'] ^ request['artifact']).bit_count()
        matches = current['artifact'] == request['artifact']
        if tier != 'artifact' and method != 'surface_continuation':
            for phase, observed in enumerate(request['earlier_artifacts']):
                past = forward(request['context'], hypothesis, phase)
                for kind in COST_KINDS:
                    costs.charge('hypothetical_execution' if kind in ('actual_execution', 'training_acquisition') else kind, past['costs'][kind])
                mismatch += (past['artifact'] ^ observed).bit_count()
                matches = matches and past['artifact'] == observed
        if tier == 'recorded_process' and method == 'inverse_maker':
            matches = matches and current['process'] == request['recorded_process']
        weights.append(float(matches) if method == 'inverse_maker' else 1 / (1 + mismatch))
        forecasts.append(future['choice'])
        compatible.append(matches)
        costs.charge('selection')
    if not sum(weights):
        raise ValueError('declared maker family cannot explain retained evidence')
    weights = b.normalize(weights)
    probabilities = {label: 0.0 for label in support}
    for label, weight in zip(forecasts, weights):
        probabilities[label] += weight
    return dict(probabilities=probabilities, costs=costs.receipt(16), compatible_histories=sum(compatible), represented_hypotheses=len(weights), represented_variables=['possible_goal', 'native_maker_policy'] if method == 'inverse_maker' else ['artifact_similarity'])
