from itertools import product
import math
import random
from ..v16.records import digest, seed_for
from .contracts import Costs, forecast_scores
from .programs import execute
METHODS = ('surface_task', 'retrieval', 'inferred_recipient', 'supplied_recipient_ceiling')

def normalize(weights):
    total = math.fsum(weights)
    if not math.isfinite(total) or total <= 0:
        raise ValueError('nonpositive or nonfinite normalization')
    return [w / total for w in weights]

def softmax(values, precision=1.0):
    peak = max(values)
    return normalize([math.exp(precision * (x - peak)) for x in values])

def recipient(artifact, world, model, costs=None):
    """Likelihood comes from executable distances to visible target configurations."""
    if type(artifact) is not int or not 0 <= artifact < 65536:
        raise ValueError('invalid graphic artifact')
    order, precision, prior = (model['order'], model['precision'], model['prior'])
    if sorted(order) != list(range(len(world['templates']))):
        raise ValueError('invalid recipient permutation')
    if len(prior) != len(order) or any((p <= 0 for p in prior)):
        raise ValueError('invalid recipient prior')
    logits = []
    for interpretation, template_index in enumerate(order):
        distance = ((artifact ^ world['templates'][template_index]) & world['visible']).bit_count()
        if costs:
            costs.charge('hypothetical_execution', world['visible'].bit_count())
        logits.append(math.log(prior[interpretation]) - precision * distance)
    return softmax(logits)

def model_space(world):
    n = len(world['templates'])
    for offset, precision, bias in product(range(n), (0.4, 1.2, 3.0), range(n + 1)):
        prior = [1.0 if bias == n else 3.0 if k == bias else 1.0 for k in range(n)]
        yield dict(order=[(k + offset) % n for k in range(n)], precision=precision, prior=normalize(prior))

def infer_models(world, demonstrations, *, effort=None, costs=None):
    models = list(model_space(world))
    if effort is not None and effort < len(models):
        indices = [i * len(models) // effort for i in range(effort)]
        models = [models[i] for i in indices]
    logs = []
    for model in models:
        ll = 0.0
        for demonstration in demonstrations:
            p = recipient(demonstration['artifact'], world, model, costs)
            ll += math.log(p[demonstration['response']])
            if costs:
                costs.charge('selection')
        logs.append(ll)
    return list(zip(models, softmax(logs)))

def mixture(artifact, world, models, costs=None):
    result = [0.0] * len(world['templates'])
    for model, weight in models:
        p = recipient(artifact, world, model, costs)
        for k, value in enumerate(p):
            result[k] += weight * value
    return normalize(result)

def opportunities(artifact, world):
    active = sorted({c for template in world['templates'] for c in range(16) if template & 1 << c})
    candidates = [{'id': 'STOP', 'program': [], 'artifact': artifact}]
    for cell in active:
        action = cell + 16 if artifact & 1 << cell else cell
        result = execute([action], initial=artifact)
        candidates.append({'id': str(action), 'program': [action], 'artifact': result['artifact']})
    return candidates

def outcome_value(probabilities, desired):
    return -sum(((a - b) ** 2 for a, b in zip(probabilities, desired)))

def utilities(candidates, world, desired, models, role, costs):
    target = world['templates'][max(range(len(desired)), key=desired.__getitem__)]
    values = []
    for candidate in candidates:
        costs.charge('proposal_generation')
        costs.charge('hypothetical_execution', len(candidate['program']))
        if role == 'physical':
            value = -((candidate['artifact'] ^ target) & world['visible']).bit_count() / world['visible'].bit_count()
        else:
            value = outcome_value(mixture(candidate['artifact'], world, models, costs), desired)
        values.append(value - 0.025 * len(candidate['program']))
        costs.charge('selection')
    return values

def accepted_distribution(candidates, world, desired, models, role, knowledge, costs):
    """Enumerate actual proposal and original-maker ratification probabilities."""
    if knowledge == 'incomplete':
        belief = [(dict(m, precision=0.0), weight) for m, weight in models]
    elif knowledge == 'wrong':
        belief = [(dict(m, order=m['order'][1:] + m['order'][:1]), weight) for m, weight in models]
    else:
        belief = models
    editor_role = 'communicator' if role == 'producer_editor' else role
    proposer = softmax(utilities(candidates, world, desired, belief, editor_role, costs), 5)
    if role != 'producer_editor':
        return proposer
    physical = utilities(candidates, world, desired, models, 'physical', costs)
    effect = utilities(candidates, world, desired, models, 'communicator', costs)
    retained = [0.0] * len(candidates)
    for i, mass in enumerate(proposer):
        costs.charge('selection')
        keep = i if 0.25 * physical[i] + effect[i] >= 0.25 * physical[0] + effect[0] else 0
        retained[keep] += mass
    return normalize(retained)

def predict(public, method, *, supplied_model=None, effort=None):
    expected = {'schema', 'world', 'artifact', 'candidates', 'shared_brief', 'role', 'editor_knowledge_condition', 'calibration', 'query_cost', 'answer_support'}
    if set(public) != expected or public['schema'] != 'v17.recipient.1':
        raise ValueError('recipient public schema violation')
    world, costs = (public['world'], Costs())
    if public['candidates'] != opportunities(public['artifact'], world) or public['answer_support'] != [c['id'] for c in public['candidates']]:
        raise ValueError('invalid public candidate execution/support')
    costs.charge('training_acquisition', len(public['calibration']))
    if method == 'supplied_recipient_ceiling':
        if supplied_model is None:
            raise ValueError('ceiling requires an explicitly supplied recipient')
        models = [(supplied_model, 1.0)]
        costs.charge('definition_storage', len(supplied_model['order']) * 2 + 1)
    elif method == 'inferred_recipient':
        models = infer_models(world, public['calibration'], effort=effort, costs=costs)
        costs.charge('definition_storage', sum((2 * len(m['order']) + 2 for m, _ in models)))
    elif method == 'surface_task':
        n = len(world['templates'])
        models = [(dict(order=list(range(n)), precision=1.2, prior=[1 / n] * n), 1.0)]
        costs.charge('definition_storage', 2 * n + 1)
    elif method == 'retrieval':
        models = []
        costs.charge('definition_storage', len(public['calibration']) * 2)
    else:
        raise ValueError('unknown recipient method')
    candidates = public['candidates']
    if method == 'retrieval':
        values = []
        predicted = []
        for candidate in candidates:
            distances = []
            for example in public['calibration']:
                costs.charge('retrieval', 2)
                distances.append((candidate['artifact'] ^ example['artifact']).bit_count())
            nearest = min(distances)
            n = len(world['templates'])
            counts = [1.0] * n
            for example, distance in zip(public['calibration'], distances):
                costs.charge('selection')
                if distance == nearest:
                    counts[example['response']] += 1
            predicted.append(normalize(counts))
            values.append(outcome_value(predicted[-1], public['shared_brief']) - 0.025 * len(candidate['program']))
            costs.charge('proposal_generation')
        edit = softmax(values, 5)
    else:
        edit = accepted_distribution(candidates, world, public['shared_brief'], models, 'physical' if method == 'surface_task' else public['role'], public['editor_knowledge_condition'], costs)
        predicted = [mixture(c['artifact'], world, models, costs) for c in candidates]
    effect = normalize([sum((w * p[k] for w, p in zip(edit, predicted))) for k in range(len(world['templates']))])
    return {'edit': dict(zip(public['answer_support'], edit)), 'recipient': {str(i): p for i, p in enumerate(effect)}, 'costs': costs.receipt(16), 'represented_variables': ['artifact', 'recipient_convention', 'recipient_precision', 'recipient_prior'] if method in ('inferred_recipient', 'supplied_recipient_ceiling') else ['artifact', 'empirical_response'], 'hypotheses': len(models)}
