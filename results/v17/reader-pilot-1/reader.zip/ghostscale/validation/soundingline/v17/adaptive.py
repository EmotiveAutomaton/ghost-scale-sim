import copy
import math
import random
from ..v16.records import digest, seed_for
from .contracts import Costs, COST_KINDS, forecast_scores
from . import recipient as b
METHODS = ('anytime_inverse', 'variable_expansion', 'learned_controller', 'fixed_inverse', 'empirical', 'confidence_refinement', 'entropy_refinement')
OPTIONS = ('cached', 'retrieval', 'inverse_3', 'inverse_9', 'inverse_full')

def option_prediction(public, option):
    task, meta = (public['task'], public['resource_context'])
    if option == 'cached':
        n = len(task['world']['templates'])
        if meta['has_current_access']:
            result = b.predict(task, 'surface_task')
            result['represented_variables'] = ['visible_artifact', 'current_access']
            return result
        counts = Costs()
        counts.charge('retrieval')
        return dict(recipient={str(k): 1 / n for k in range(n)}, costs=counts.receipt(16), represented_variables=['current_access'], hypotheses=0)
    if option == 'retrieval':
        return b.predict(task, 'retrieval')
    effort = {'inverse_3': 3, 'inverse_9': 9, 'inverse_full': len(list(b.model_space(task['world'])))}[option]
    effort = min(effort, meta['hypothesis_limit'])
    return b.predict(task, 'inferred_recipient', effort=effort)
