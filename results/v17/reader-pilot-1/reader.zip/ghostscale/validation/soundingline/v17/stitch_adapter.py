import ctypes
from itertools import product
import json
import os
from pathlib import Path
import re
import subprocess
import time
from ..v16.records import canonical, digest
PIN = '350804b7b35807c78bd21c313785ae5152ae2985'

def sexpr(text):
    tokens = re.findall('\\(|\\)|[^\\s()]+', text)

    def node(index):
        token = tokens[index]
        if token == '(':
            values = []
            index += 1
            while index < len(tokens) and tokens[index] != ')':
                value, index = node(index)
                values.append(value)
            if index == len(tokens):
                raise ValueError('unclosed expression')
            return (values, index + 1)
        if token == ')':
            raise ValueError('unexpected close')
        return (token, index + 1)
    result, end = node(0)
    if end != len(tokens):
        raise ValueError('trailing expression')
    return result

def expand(expression, definitions, arguments=(), world='graphic', depth=0):
    if depth > 12:
        raise ValueError('recursive abstraction')
    if isinstance(expression, str):
        if expression in definitions:
            body, arity = definitions[expression]
            if arity:
                raise ValueError('missing abstraction arguments')
            return expand(body, definitions, (), world, depth + 1)
        raise ValueError('program token not an expression')
    if not expression:
        raise ValueError('empty expression')
    op = expression[0]

    def argument(token):
        if not isinstance(token, str):
            raise ValueError('higher-order argument rejected')
        if token.startswith('#'):
            index = int(token[1:])
            if not 0 <= index < len(arguments):
                raise ValueError('unbound typed argument')
            value = arguments[index]
        elif re.fullmatch('c[0-9]+', token):
            value = int(token[1:])
        else:
            raise ValueError('non-cell argument')
        if type(value) is not int or not 0 <= value < (16 if world == 'graphic' else 3):
            raise ValueError('cell or part outside domain')
        return value
    if op == 'seq':
        return [a for item in expression[1:] for a in expand(item, definitions, arguments, world, depth + 1)]
    offsets = {'place': 0, 'remove': 16} if world == 'graphic' else {'attach': 0, 'remove': 3, 'rotate': 6}
    if op in offsets and len(expression) == 2:
        return [offsets[op] + argument(expression[1])]
    if op in definitions:
        body, arity = definitions[op]
        if len(expression) - 1 != arity:
            raise ValueError('wrong learned arity')
        return expand(body, definitions, tuple((argument(t) for t in expression[1:])), world, depth + 1)
    raise ValueError('unsupported typed program')

def encode(program, world='graphic'):

    def action(a):
        if world == 'graphic':
            return f"({('place' if a < 16 else 'remove')} c{a % 16})"
        if a == 9:
            return None
        return f"({('attach', 'remove', 'rotate')[a // 3]} c{a % 3})"
    return '(seq ' + ' '.join((x for a in program if (x := action(a)) is not None)) + ')'
