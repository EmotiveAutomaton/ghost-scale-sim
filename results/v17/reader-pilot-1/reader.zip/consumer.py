"""Read public JSON lines and write probability forecasts; standard library only."""
import argparse,json,sys
from ghostscale.validation.soundingline.v17.observer import predict
parser=argparse.ArgumentParser()
parser.add_argument("--method",default="inverse_maker")
parser.add_argument("--guard-probe",action="store_true")
args=parser.parse_args()
def guard(event,values):
    if event in ("open","os.system","subprocess.Popen","socket.connect","socket.bind"):
        raise PermissionError("reader evidence boundary")
sys.addaudithook(guard)
if args.guard_probe:
    try:
        open("PRIVATE-canary.txt")
    except PermissionError:
        print(json.dumps({"private_read_denied":True}))
        raise SystemExit(0)
    raise SystemExit(2)
for line in sys.stdin:
    request=json.loads(line)
    task_id=request.pop("task_id")
    result=predict(request,args.method)
    print(json.dumps({"schema":"v17.prediction.1","task_id":task_id,**result},allow_nan=False),flush=True)
