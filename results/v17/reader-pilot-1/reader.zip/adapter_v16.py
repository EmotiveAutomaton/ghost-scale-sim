"""Versioned envelope adapter; leaves v16.transfer.1 payloads unchanged."""
def adapt(request):
    if request.get("schema")=="v17.observer.1":
        return {"adapter_schema":"ghostscale.transfer.adapter.1","payload_schema":"v17.observer.1","payload":request}
    if request.get("schema_version")=="v16.transfer.1" or request.get("schema")=="v16.transfer.1":
        return {"adapter_schema":"ghostscale.transfer.adapter.1","payload_schema":"v16.transfer.1","payload":request}
    raise ValueError("unsupported transfer schema")
